﻿using System.Reflection.Metadata.Ecma335;

namespace Cars
{
   public interface ICar
    {
        public string Model { get; set; }
        public string Color { get; set; }
        string Start();
        string Stop();
    }
    public interface IElectricCar:ICar
    {
        public int Battery { get; set; }
    }
    public class Seat : ICar
    {
        string model;
        string color;
        public Seat(string model,string color)
        {
            Model = model;
            Color = color;
        }
        public string Model { get => model; set => model = value; }
        public string Color { get => color; set => color = value; }

        public string Start()
        {
            return "Engine start";
        }

        public string Stop()
        {
            return "Breaaak!";
        }
        public override string ToString()
        {
            return $"{color} Seat {model}";
        }
    }
    public class Tesla : IElectricCar
    {
        string model;
        string color;
        int battery;
        public Tesla(string model, string color, int battery)
        {
            Model = model;
            Color = color;
            Battery = battery;

        }
        public string Model { get => model; set => model = value; }
        public string Color { get => color; set => color = value; }
        public int Battery { get => battery; set => battery = value; }

        public string Start()
        {
            return "Engine start";
        }

        public string Stop()
        {
            return "Breaaak!";
        }
        public override string ToString()
        {
            return $"{color} Tesla {model} with {battery} Batteries.";
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ICar seat = new Seat("Leon", "Grey");

            ICar tesla = new Tesla("Model 3", "Red", 2);

            Console.WriteLine(seat.ToString());

            Console.WriteLine(tesla.ToString());
        }
    }
}
