﻿namespace Shapes
{
    public interface IDrawable
    {
        public void Draw();
    }
    public class Circle : IDrawable
    {
        int radius;
        public Circle(int radius)
        {
            Radius = radius;
        }
        public int Radius { get => radius; set => radius = value; }
        void IDrawable.Draw()
        {
            double rIn = this.radius - 0.4;
            double rOut = this.radius + 0.4;
            for (double y = this.radius; y >= -this.radius; --y)
            {
                for (double x = -this.radius; x < rOut; x += 0.5)
                {
                    double value = x * x + y * y;
                    if (value >= rIn * rIn && value <= rOut * rOut)
                        Console.Write("*");
                    else
                        Console.Write(" ");
                }
                Console.WriteLine();
            }
        }
    }
    public class Rectangle : IDrawable
    {
        int width;
        int height;
        public Rectangle(int width,int height)
        {
            Width = width;
            Height = height;
        }
        public int Width { get => width; set => width = value; }
        public int Height { get => height; set => height = value; }
        void IDrawable.Draw()
        {
            DrawLine(this.width, '*', '*');
            for (int i = 1; i < this.height - 1; ++i)
                DrawLine(this.width, '*', ' ');
            DrawLine(this.width, '*', '*');
        }
        private void DrawLine(int width, char end, char mid)
        {
            Console.Write(end);
            for (int i = 1; i < width - 1; ++i)
                Console.Write(mid);
            Console.WriteLine(end);
        }
    }

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var radius = int.Parse(Console.ReadLine());

            IDrawable circle = new Circle(radius);

            var width = int.Parse(Console.ReadLine());

            var height = int.Parse(Console.ReadLine());

            IDrawable rect = new Rectangle(width, height);

            circle.Draw();

            rect.Draw();

        }
    }
}
