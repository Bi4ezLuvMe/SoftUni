﻿using System.Threading.Tasks;

namespace Shapes
{
    public interface IDrivable
    {
        double FuelQuantity { get; set; }
        double FuelConsumption { get; set; }
        double TankCapacity { get; set; }
        bool CanDrive(double distance);
        void Refuel(double liters);
    }
    public class Car : IDrivable
    {
        double fuelQuantity;
        double fuelConsumption;
        double tankCapacity;
        public Car(double fuelQuantity, double fuelConsumption,double tankCapacity)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
            TankCapacity = tankCapacity;
        }
        public double FuelQuantity { get => fuelQuantity; set => fuelQuantity = value; }
        public double FuelConsumption { get => fuelConsumption; set => fuelConsumption = value + 0.9; }
        public double TankCapacity { get => tankCapacity; set => tankCapacity = value; }
        public bool CanDrive(double distance) => (distance * fuelConsumption < fuelQuantity) ? true : false;
        public void Refuel(double liters) 
        {
            if (liters+fuelQuantity <= tankCapacity)
            {
                fuelQuantity += liters ;
            }
            else
            {
                Console.WriteLine($"Cannot fit {liters} fuel in the tank");
            }
        }
    }
    public class Truck : IDrivable
    {
        double fuelQuantity;
        double fuelConsumption;
        double tankCapacity;
        public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
           TankCapacity = tankCapacity;
        }
        public double FuelQuantity { get => fuelQuantity; set => fuelQuantity = value ; }
        public double FuelConsumption { get => fuelConsumption; set => fuelConsumption = value + 1.6; }
        public double TankCapacity { get => tankCapacity; set => tankCapacity = value; }
        public bool CanDrive(double distance)
        {
            return (distance * fuelConsumption < fuelQuantity) ? true : false;
        }
        public void Refuel(double liters)
        {
            if (liters * 0.95 + fuelQuantity <= tankCapacity)
            {
                fuelQuantity += liters * 0.95;
            }
            else
            {
                Console.WriteLine($"Cannot fit {liters} fuel in the tank" );
            }
        }
    }
    public class Bus : IDrivable
    {
        double fuelQuantity;
        double fuelConsumption;
        double tankCapacity;
        public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
            TankCapacity = tankCapacity;
        }
        public double FuelQuantity { get => fuelQuantity; set => fuelQuantity = value; }
        public double FuelConsumption { get => fuelConsumption; set => fuelConsumption = value; }
        public double TankCapacity { get => tankCapacity; set => tankCapacity = value; }
        public bool CanDrive(double distance) => (distance * fuelConsumption < fuelQuantity) ? true : false;
        public void Refuel(double liters)
        {
            if (liters + fuelQuantity <= tankCapacity)
            {
                fuelQuantity += liters;
            }
            else
            {
                Console.WriteLine($"Cannot fit {liters} fuel in the tank");
            }
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] carTokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] truckTokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] busTokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double carFuelQuantity = double.Parse(carTokens[1]);
            double carFuelConsumption = double.Parse(carTokens[2]);
            double carTank = double.Parse(carTokens[3]);
            double truckFuelQuantity = double.Parse(truckTokens[1]);
            double truckFuelConsumption = double.Parse(truckTokens[2]);
            double truckTank = double.Parse(truckTokens[3]);
            double busFuelQuantity = double.Parse(busTokens[1]);
            double busFuelConsumption = double.Parse(busTokens[2]);
            double busTank = double.Parse(busTokens[3]);
            if (carFuelQuantity > carTank)
            {
                carFuelQuantity = 0;
            }
            if (truckFuelQuantity > truckTank)
            {
                truckFuelQuantity = 0;
            }
            if (busFuelQuantity > busTank)
            {
                busFuelQuantity = 0;
            }
            Car car = new(carFuelQuantity, carFuelConsumption, carTank);
            Truck truck = new(truckFuelQuantity, truckFuelConsumption, truckTank);
            Bus bus = new(busFuelQuantity,busFuelConsumption,busTank);
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens[0] == "Drive")
                {
                    double distance = double.Parse(tokens[2]);
                    if (tokens[1] == "Car")
                    {
                        if (car.CanDrive(distance))
                        {
                            Console.WriteLine($"Car travelled {distance} km");
                            car.FuelQuantity -= distance * car.FuelConsumption;
                        }
                        else
                        {
                            Console.WriteLine($"Car needs refueling");
                        }
                    }
                    else if (tokens[1] == "Truck")
                    {
                        if (truck.CanDrive(distance))
                        {
                            Console.WriteLine($"Truck travelled {distance} km");
                            truck.FuelQuantity -= distance * truck.FuelConsumption;
                        }
                        else
                        {
                            Console.WriteLine($"Truck needs refueling");
                        }
                    }else if (tokens[1] == "Bus")
                    {
                        bus.FuelConsumption += 1.4;
                        if (bus.CanDrive(distance))
                        {
                            Console.WriteLine($"Bus travelled {distance} km");
                            bus.FuelQuantity -= distance * bus.FuelConsumption;
                        }
                        else
                        {
                            Console.WriteLine($"Bus needs refueling");
                        }
                        bus.FuelConsumption -= 1.4;
                    }
                }
                else if (tokens[0] == "Refuel")
                {
                    double liters = double.Parse(tokens[2]);
                    if (liters > 0)
                    {
                        if (tokens[1] == "Car")
                        {
                            car.Refuel(liters);
                        }
                        else if (tokens[1] == "Truck")
                        {
                            truck.Refuel(liters);
                        }
                        else if (tokens[1] == "Bus")
                        {
                            bus.Refuel(liters);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Fuel must be a positive number");
                    }
                }
                else if (tokens[0]== "DriveEmpty")
                {
                    double distance = double.Parse(tokens[2]);
                    if (bus.CanDrive(distance))
                    {
                        Console.WriteLine($"Bus travelled {distance} km");
                        bus.FuelQuantity -= distance * bus.FuelConsumption;
                    }
                    else
                    {
                        Console.WriteLine($"Bus needs refueling");
                    }
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:f2}");
        }
    }
}
