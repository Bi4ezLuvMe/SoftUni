﻿namespace Shapes
{
    public abstract class BaseHero
    {
        string name;
        public BaseHero(string name)
        {
            Name = name;
        }
        public string Name { get => name; set => name = value; }
        public  int Power { get; set; }
        public abstract string CastAbility();
    }
    public class Druid : BaseHero
    {
       
        public Druid(string name) : base(name)
        {
            Power = 80;
        }
        public override string CastAbility() => $"Druid - {Name} healed for {Power}";
    }
    public class Paladin : BaseHero
    {
        public Paladin(string name) : base(name)
        {
            Power = 100;
        }
        public override string CastAbility() => $"Paladin - {Name} healed for {Power}";
    }
    public class Rogue : BaseHero
    {
        public Rogue(string name) : base(name)
        {
            Power = 80;
        }
        public override string CastAbility() => $"Rogue - {Name} hit for {Power} damage";
    }
    public class Warrior : BaseHero
    {
        public Warrior(string name) : base(name)
        {
            Power = 100;
        }
        public override string CastAbility() => $"Warrior - {Name} hit for {Power} damage";
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<BaseHero> raiders = new List<BaseHero>();
            BaseHero hero;

            int n = int.Parse(Console.ReadLine());
            int counter = 0;

            while (counter != n)
            {
                string name = Console.ReadLine();
                string type = Console.ReadLine();

                try
                {
                    if (type == "Druid")
                    {
                        hero = new Druid(name);
                    }
                    else if (type == "Paladin")
                    {
                        hero = new Paladin(name);
                    }
                    else if (type == "Rogue")
                    {
                        hero = new Rogue(name);

                    }
                    else if (type == "Warrior")
                    {
                        hero = new Warrior(name);
                    }
                    else
                    {
                        throw new ArgumentException("Invalid hero!");
                    }

                    counter++;

                    raiders.Add(hero);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            long bossPower = long.Parse(Console.ReadLine());


            foreach (var r in raiders)
            {
                Console.WriteLine(r.CastAbility());
            }

            long allPower = raiders.Select(x => x.Power).Sum();

            if (allPower >= bossPower)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }
        }
    }
}