﻿namespace Shapes
{
    public interface IDrivable
    {
        double FuelQuantity { get; set; }
        double FuelConsumption { get; set; }
        bool CanDrive(double distance);
        void Refuel(double liters);
    }
    public class Car : IDrivable
    {
        double fuelQuantity;
        double fuelConsumption;
        public Car(double fuelQuantity, double fuelConsumption)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
        }
        public double FuelQuantity { get => fuelQuantity; set => fuelQuantity = value; }
        public double FuelConsumption { get => fuelConsumption; set => fuelConsumption = value + 0.9; }
        public bool CanDrive(double distance) => (distance * fuelConsumption < fuelQuantity) ? true : false;
        public void Refuel(double liters) => fuelQuantity += liters;
    }
    public class Truck : IDrivable
    {
        double fuelQuantity;
        double fuelConsumption;
        public Truck(double fuelQuantity, double fuelConsumption)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
        }
        public double FuelQuantity { get => fuelQuantity; set => fuelQuantity = value ; }
        public double FuelConsumption { get => fuelConsumption; set => fuelConsumption = value + 1.6; }
        public bool CanDrive(double distance)
        {
            return (distance * fuelConsumption < fuelQuantity) ? true : false;
        }
        public void Refuel(double liters)
        {
            fuelQuantity += liters * 0.95;
        }
    }

    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] carTokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] truckTokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Car car = new(double.Parse(carTokens[1]), double.Parse(carTokens[2]));
            Truck truck = new(double.Parse(truckTokens[1]), double.Parse(truckTokens[2]));
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens[0] == "Drive")
                {
                    double distance = double.Parse(tokens[2]);
                    if (tokens[1] == "Car")
                    {
                        if (car.CanDrive(distance))
                        {
                            Console.WriteLine($"Car travelled {distance} km");
                            car.FuelQuantity -= distance * car.FuelConsumption;
                        }
                        else
                        {
                            Console.WriteLine($"Car needs refueling");
                        }
                    }
                    else if (tokens[1] == "Truck")
                    {
                        if (truck.CanDrive(distance))
                        {
                            Console.WriteLine($"Truck travelled {distance} km");
                            truck.FuelQuantity -= distance * truck.FuelConsumption;
                        }
                        else
                        {
                            Console.WriteLine($"Truck needs refueling");
                        }
                    }
                }
                else if (tokens[0] == "Refuel")
                {
                    double liters = double.Parse(tokens[2]);
                    if (tokens[1] == "Car")
                    {
                        car.Refuel(liters);
                    }
                    else if (tokens[1] == "Truck")
                    {
                        truck.Refuel(liters);
                    }
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}
