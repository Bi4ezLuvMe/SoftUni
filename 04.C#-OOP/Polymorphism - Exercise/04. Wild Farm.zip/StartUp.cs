﻿namespace Shapes
{
    public abstract class Food
    {
        public Food(int quantity)
        {
            Quantity = quantity;
        }
        public int Quantity { get; set; }
    }
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {

        }
    }
    public abstract class Animal
    {
        public Animal(string name, double weight, int foodEaten)
        {
            Name = name;
            Weight = weight;
            FoodEaten = foodEaten;
        }
        public string Name { get; set; }
        public double Weight { get; set; }
        public int FoodEaten { get; set; }
        public abstract string ProduceSound();
    }
    public abstract class Bird : Animal
    {
        public Bird(string name, double weight, int foodEaten, double wingSize) : base(name, weight, foodEaten)
        {
            WingSize = wingSize;
        }

        public double WingSize { get; set; }
        public override string ToString()
        {
            return $"{GetType().Name} [{Name}, {WingSize}, {Weight}, {FoodEaten}]";
        }
    }
    public class Owl : Bird
    {
        public Owl(string name, double weight, int foodEaten, double wingSize) : base(name, weight, foodEaten, wingSize)
        {
        }

        public override string ProduceSound() => "Hoot Hoot";
    }
    public class Hen : Bird
    {
        public Hen(string name, double weight, int foodEaten, double wingSize) : base(name, weight, foodEaten, wingSize)
        {
        }

        public override string ProduceSound() => "Cluck";
    }
    public abstract class Mammal : Animal
    {
        public Mammal(string name, double weight, int foodEaten, string livingRegion) : base(name, weight, foodEaten)
        {
            LivingRegion = livingRegion;
        }

        public string LivingRegion { get; set; }
    }
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, int foodEaten, string livingRegion) : base(name, weight, foodEaten, livingRegion)
        {
        }

        public override string ProduceSound() => "Squeak";
        public override string ToString()
        {
            return $"{GetType().Name} [{Name}, {Weight}, {LivingRegion}, {FoodEaten}]";
        }
    }
    public class Dog : Mammal
    {
        public Dog(string name, double weight, int foodEaten, string livingRegion) : base(name, weight, foodEaten, livingRegion)
        {
        }

        public override string ProduceSound() => "Woof!";
        public override string ToString()
        {
            return $"{GetType().Name} [{Name}, {Weight}, {LivingRegion}, {FoodEaten}]";
        }
    }

    public abstract class Feline : Mammal
    {
        protected Feline(string name, double weight, int foodEaten, string livingRegion, string breed) : base(name, weight, foodEaten, livingRegion)
        {
            Breed = breed;
        }

        public string Breed { get; set; }
        public override string ToString()
        {
            return $"{GetType().Name} [{Name}, {Breed}, {Weight}, {LivingRegion}, {FoodEaten}]";
        }
    }
    public class Tiger : Feline
    {
        public Tiger(string name, double weight, int foodEaten, string livingRegion, string breed) : base(name, weight, foodEaten, livingRegion, breed)
        {
        }

        public override string ProduceSound() => "ROAR!!!";
    }
    public class Cat : Feline
    {
        public Cat(string name, double weight, int foodEaten, string livingRegion, string breed) : base(name, weight, foodEaten, livingRegion, breed)
        {
        }

        public override string ProduceSound() => "Meow";
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<Animal> animals = new();
            int counter = 0;
            string type = String.Empty;
            string name = String.Empty;
            double weight = 0;
            string livingRegion = String.Empty;
            string breed = String.Empty;
            double wingSize = 0;
            while (command != "End")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (counter % 2 == 0)
                {
                    switch (tokens[0])
                    {
                        case "Cat":
                            type = tokens[0];
                            name = tokens[1];
                            weight = double.Parse(tokens[2]);
                            livingRegion = tokens[3];
                            breed = tokens[4];
                            Console.WriteLine("Meow");
                            break;
                        case "Tiger":
                            type = tokens[0];
                            name = tokens[1];
                            weight = double.Parse(tokens[2]);
                            livingRegion = tokens[3];
                            breed = tokens[4];
                            Console.WriteLine("ROAR!!!");
                            break;
                        case "Owl":
                            type = tokens[0];
                            name = tokens[1];
                            weight = double.Parse(tokens[2]);
                            wingSize = double.Parse(tokens[3]);
                            Console.WriteLine("Hoot Hoot");
                            break;
                        case "Hen":
                            type = tokens[0];
                            name = tokens[1];
                            weight = double.Parse(tokens[2]);
                            wingSize = double.Parse(tokens[3]);
                            Console.WriteLine("Cluck");
                            break;
                        case "Mouse":
                            type = tokens[0];
                            name = tokens[1];
                            weight = double.Parse(tokens[2]);
                            livingRegion = tokens[3];
                            Console.WriteLine("Squeak");
                            break;
                        case "Dog":
                            type = tokens[0];
                            name = tokens[1];
                            weight = double.Parse(tokens[2]);
                            livingRegion = tokens[3];
                            Console.WriteLine("Woof!");
                            break;
                    }
                }
                else
                {
                    int quantity = int.Parse(tokens[1]);
                    switch (tokens[0])
                    {
                        case "Vegetable":
                            switch (type)
                            {
                                case "Hen":
                                    weight += quantity * 0.35;
                                    Hen hen = new(name, weight, quantity, wingSize);
                                    animals.Add(hen);
                                    break;
                                case "Mouse":
                                    weight += quantity * 0.10;
                                    Mouse mouse = new(name, weight, quantity, livingRegion);
                                    animals.Add(mouse);
                                    break;
                                case "Cat":
                                    weight += quantity * 0.30;
                                    Cat cat = new(name, weight, quantity, livingRegion, breed);
                                    animals.Add(cat);
                                    break;

                                default:
                                    Console.WriteLine($"{type} does not eat Vegetable!");
                                    switch (type)
                                    {
                                        case "Tiger":
                                            Tiger tiger = new(name, weight, 0, livingRegion, breed);
                                            animals.Add(tiger);
                                            break;
                                        case "Dog":
                                            Dog dog = new(name, weight, 0, livingRegion);
                                            animals.Add(dog);
                                            break;
                                        case "Owl":
                                            Owl owl = new(name, weight, 0, wingSize);
                                            animals.Add(owl);
                                            break;
                                    }
                                    break;
                            }
                            break;
                        case "Fruit":
                            switch (type)
                            {
                                case "Mouse":
                                    weight += quantity * 0.10;
                                    Mouse mouse = new(name, weight, quantity, livingRegion);
                                    animals.Add(mouse);
                                    break;
                                case "Hen":
                                    weight += quantity * 0.35;
                                    Hen hen = new(name, weight, quantity, wingSize);
                                    animals.Add(hen);
                                    break;
                                default:
                                    Console.WriteLine($"{type} does not eat Fruit!");
                                    switch (type)
                                    {
                                        case "Tiger":
                                            Tiger tiger = new(name, weight, 0, livingRegion, breed);
                                            animals.Add(tiger);
                                            break;
                                        case "Dog":
                                            Dog dog = new(name, weight, 0, livingRegion);
                                            animals.Add(dog);
                                            break;
                                        case "Owl":
                                            Owl owl = new(name, weight, 0, wingSize);
                                            animals.Add(owl);
                                            break;
                                        case "Cat":
                                            Cat cat = new(name, weight, 0, livingRegion, breed);
                                            animals.Add(cat);
                                            break;
                                    }
                                    break;
                            }
                            break;
                        case "Meat":
                            switch (type)
                            {
                                case "Hen":
                                    weight += quantity * 0.35;
                                    Hen hen = new(name, weight, quantity, wingSize);
                                    animals.Add(hen);
                                    break;
                                case "Cat":
                                    weight += quantity * 0.30;
                                    Cat cat = new(name, weight, quantity, livingRegion, breed);
                                    animals.Add(cat);
                                    break;
                                case "Tiger":
                                    weight += quantity * 1.00;
                                    Tiger tiger = new(name, weight, quantity, livingRegion, breed);
                                    animals.Add(tiger);
                                    break;
                                case "Dog":
                                    weight += quantity * 0.40;
                                    Dog dog = new(name, weight, quantity, livingRegion);
                                    animals.Add(dog);
                                    break;
                                case "Owl":
                                    weight += quantity * 0.25;
                                    Owl owl = new(name, weight, quantity, wingSize);
                                    animals.Add(owl);
                                    break;
                                default:
                                    Console.WriteLine($"{type} does not eat Meat!");
                                    switch (type)
                                    {
                                        case "Mouse":
                                            Mouse mouse = new(name, weight, 0, livingRegion);
                                            animals.Add(mouse);
                                            break;
                                    }
                                    break;
                            }
                            break;
                        case "Seed":
                            switch (type)
                            {
                                case "Hen":
                                    weight += quantity * 0.35;
                                    Hen hen = new(name, weight, quantity, wingSize);
                                    animals.Add(hen);
                                    break;
                                default:
                                    Console.WriteLine($"{type} does not eat Seed!");
                                    switch (type)
                                    {
                                        case "Tiger":
                                            Tiger tiger = new(name, weight, 0, livingRegion, breed);
                                            animals.Add(tiger);
                                            break;
                                        case "Dog":
                                            Dog dog = new(name, weight, 0, livingRegion);
                                            animals.Add(dog);
                                            break;
                                        case "Owl":
                                            Owl owl = new(name, weight, 0, wingSize);
                                            animals.Add(owl);
                                            break;
                                        case "Cat":
                                            Cat cat = new(name, weight, 0, livingRegion, breed);
                                            animals.Add(cat);
                                            break;
                                        case "Mouse":
                                            Mouse mouse = new(name, weight, 0, livingRegion);
                                            animals.Add(mouse);
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                }
                counter++;
                command = Console.ReadLine();
            }
            foreach (var item in animals)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}