﻿namespace PersonsInfo
{
    public class Person
    {
        string firstName;
        string lastName;
        int age;
        decimal salary;
        public Person(string firstName, string lastName, int age, decimal salary)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
            Salary = salary;
        }
        public string FirstName {get { return firstName; } private set {  firstName = value; } }
        public string LastName { get { return lastName; } private set { lastName = value; } }
        public int Age { get { return age; } private set { age = value; } }
        public decimal Salary { get { return salary; }private set { salary = value; } }
        public void IncreaseSalary(decimal percentage)
        {
            if (age < 30)
            {
                salary += salary * percentage/200;
                return;
            }
            salary += salary * percentage/100;
        }
        public override string ToString()
        {
            return $"{firstName} {lastName} receives {salary:f2} leva.";
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var lines = int.Parse(Console.ReadLine());
            var persons = new List<Person>();
            for (int i = 0; i < lines; i++)
            {
                var cmdArgs = Console.ReadLine().Split();
                var person = new Person(cmdArgs[0],
                cmdArgs[1],
                int.Parse(cmdArgs[2]),
                decimal.Parse(cmdArgs[3]));
                persons.Add(person);
            }
            var parcentage = decimal.Parse(Console.ReadLine());
            persons.ForEach(p => p.IncreaseSalary(parcentage));
            persons.ForEach(p => Console.WriteLine(p.ToString()));
        }
    }
}