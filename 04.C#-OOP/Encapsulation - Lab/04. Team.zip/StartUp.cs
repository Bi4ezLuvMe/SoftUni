﻿namespace PersonsInfo
{
   public class Team
    {
         List<Person> firstTeam;
         List<Person> reserveTeam;
        public IReadOnlyCollection<Person> FirstTeam
        {
            get { return firstTeam.AsReadOnly(); }
        }
        public IReadOnlyCollection<Person> ReserveTeam
        {
            get { return reserveTeam.AsReadOnly(); }
        }
        string name;
        public Team(string name)
        {
            this.name = name;
            firstTeam = new List<Person>();
            reserveTeam = new List<Person>();
        }
        public void AddPlayer(Person person)
        {
            if (person.Age < 40)
            {
                firstTeam.Add(person);
            }
            else
            {
                reserveTeam.Add(person);
            }
        }
    }
    public class Person 
    {
        int age;
        decimal salary;
        string firstName;
        string lastName;
        public Person(string firstname,string lastName, int age, decimal salary)
        {
            this.firstName = firstname;
            this.lastName = lastName;
            this.age = age;
            this.salary = salary;
        }
       public int Age { get { return age; } }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Team team = new Team("SoftUni");
            int n = int.Parse(Console.ReadLine());
            List<Person> persons = new();
            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);
                string firstName = tokens[0];
                string lastName = tokens[1];
                int age = int.Parse(tokens[2]);
                decimal salary = decimal.Parse(tokens[3]);
                Person person = new(firstName,lastName,age,salary);
                persons.Add(person);
            }
            foreach (Person person in persons)
            {
                team.AddPlayer(person);
            }
            Console.WriteLine($"First team has {team.FirstTeam.Count} players.");
            Console.WriteLine($"Reserve team has {team.ReserveTeam.Count} players.");
        }
    }
}