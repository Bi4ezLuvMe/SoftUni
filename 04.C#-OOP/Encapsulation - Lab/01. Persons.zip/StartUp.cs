﻿namespace PersonsInfo
{
    public class Person
    {
        string firstName;
        string lastName;
        int age;
        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }
        public string FirstName {get { return firstName; } private set {  firstName = value; } }
        public string LastName { get { return lastName; } private set { lastName = value; } }
        public int Age { get { return age; } private set { age = value; } }
        public override string ToString()
        {
            return $"{firstName} {lastName} is {age} years old.";
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var lines = int.Parse(Console.ReadLine());
            var persons = new List<Person>();
            for (int i = 0; i < lines; i++)
            {
                var cmdArgs = Console.ReadLine().Split();
                var person = new Person(cmdArgs[0], cmdArgs[1], int.Parse(cmdArgs[2]));
                persons.Add(person);
            }
            persons.OrderBy(p => p.FirstName)
            .ThenBy(p => p.Age)
            .ToList()
            .ForEach(p => Console.WriteLine(p.ToString()));
        }
    }
}