﻿namespace Animals
{
    public abstract class Animal
    {
        public string Name { get; set; }
        public string FavouriteFood { get; set; }
        public Animal(string name,string favouriteFood)
        {
           Name = name;
           FavouriteFood = favouriteFood;
        }
        public abstract string ExplainSelf();
    }
    public class Cat : Animal
    {
        public Cat(string name, string favouriteFood) : base(name, favouriteFood)
        {
        }
        public override string ExplainSelf()
        {
            return $"I am {Name} and my fovourite food is {FavouriteFood}{Environment.NewLine} MEEOW";
        }
    }
    public class Dog : Animal
    {
        public Dog(string name, string favouriteFood) : base(name, favouriteFood)
        {
        }
        public override string ExplainSelf()
        {
            return $"I am {Name} and my fovourite food is {FavouriteFood}{Environment.NewLine} DJAAF";
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Animal cat = new Cat("Peter", "Whiskas");

            Animal dog = new Dog("George", "Meat");

            Console.WriteLine(cat.ExplainSelf());

            Console.WriteLine(dog.ExplainSelf());

        }
    }
}
