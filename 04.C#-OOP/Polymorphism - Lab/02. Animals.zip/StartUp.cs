﻿namespace Operations
{
    public class MathOperations
    {
        public int Add(int a, int b) => a + b;
        public double Add(double a, double b, double c) => a + b + c;
        public decimal Add(decimal a, decimal b, decimal c) => a + b + c;
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            MathOperations mo = new MathOperations();

            Console.WriteLine(mo.Add(2, 3));

            Console.WriteLine(mo.Add(2.2, 3.3, 5.5));

            Console.WriteLine(mo.Add(2.2m, 3.3m, 4.4m));
        }
    }
}
