﻿using System.Diagnostics;

namespace Shapes
{
   public abstract class Shape
    {
        public abstract double CalculatePerimeter();
        public abstract double CalculateArea();
        public virtual string Draw() => $"Drawing {this.GetType().Name}";
    }

    public class Rectangle:Shape
    {
        public double Height { get; private set; }
        public double Width { get; private set; }
        public Rectangle(double height,double widght)
        {
            Height = height;
            Width = widght;
        }
        public override double CalculateArea() =>Height*Width;
        public override double CalculatePerimeter() =>2*(Width+Height);
    }
    public class Circle : Shape
    {
        public double Radius { get; private set; }
        public Circle(double radius)
        {
           Radius = radius;
        }
        public override double CalculateArea() =>Math.PI*Math.Pow(Radius,2);
        public override double CalculatePerimeter() => 2 * Math.PI*Radius;
    }

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Rectangle rec = new(5, 10);
            Circle circle = new(5);
          List<Shape> shapes = new List<Shape> { rec,circle };
            foreach (var item in shapes)
            {
                Console.WriteLine(item.Draw());
                Console.WriteLine(item.CalculatePerimeter());
                Console.WriteLine(item.CalculateArea());
            }
        }
    }
}
