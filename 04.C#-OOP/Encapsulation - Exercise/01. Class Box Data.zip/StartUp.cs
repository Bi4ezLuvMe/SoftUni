﻿namespace PersonsInfo
{
   public class Box
    {
        double length;
        double width;
        double height;
        public Box(double length, double width, double height)
        {
            Length = length;
           Width = width;
            Height = height;
        }
        public double Length { get { return length; } set { if (isValid(value)) { length = value; } else { throw new Exception("Length cannot be zero or negative."); } } }
        public double Width { get { return width; } set{ if (isValid(value)) { width = value; } else { throw new Exception("Width cannot be zero or negative."); } } }
        public double Height { get { return height; } set { if (isValid(value)) { height = value; } else { throw new Exception("Height cannot be zero or negative."); } } }
        private bool isValid(double value)
        {
            if(value < 0) return false;
            else return true;
        }
        public double SurfaceArea()
        {
            double result = 2*length*width+2*length*height+2*width*height;
            return result;
        }
        public double LateralSurfaceArea()
        {
            double result =2 * length * height + 2 * width * height;
            return result;
        }
        public double Volume()
        {
            double result = length*width*height;
            return result;
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            double length = double.Parse(Console.ReadLine());
            double width = double.Parse(Console.ReadLine());
            double height = double.Parse(Console.ReadLine());
            try
            {
                Box box = new(length, width, height);
                Console.WriteLine($"Surface Area - {box.SurfaceArea():f2}");
                Console.WriteLine($"Lateral Surface Area - {box.LateralSurfaceArea():f2}");
                Console.WriteLine($"Volume - {box.Volume():F2}");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}