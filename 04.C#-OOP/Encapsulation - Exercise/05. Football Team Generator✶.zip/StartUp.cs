﻿namespace PersonsInfo
{
    public class Team
    {
        int numberOfPlayers;
        string name;
        int rating;
        List<Player> players;
        public Team(string name)
        {
            Name = name;
            players = new List<Player>();
        }
        public string Name { get => name; set { if (string.IsNullOrWhiteSpace(value)) { throw new Exception("A name should not be empty."); } name = value; } }
        public double Rating { get => Rating1(); }
        double Rating1()
        {
            double rating = 0;
            foreach (var item in players)
            {
                rating += item.Rating;
            }
            if (players.Any())
            {
                rating /=players.Count;
                return Math.Round(rating);
            }
            return 0;
          
        }
        public void Add(Player player, string name)
        {
            if (name == Name)
            {
                players.Add(player);
            }
            else
            {
                Console.WriteLine($"Team {name} does not exist.");
            }

        }
        public void Remove(string name, string club)
        {
            if (!this.players.Any(p => p.Name == name))
            {
                throw new Exception($"Player {name} is not in {this.Name} team.");
            }
            Player pl = this.players.FirstOrDefault(p => p.Name == name);
            this.players.Remove(pl);
        }
    }
    public class Player
    {
        string name;
        int endurance;
        int sprint;
        int dribble;
        int passing;
        int shooting;
        int rating;
        public Player(string name, int endurance, int sprint, int dribble, int passing, int shooting)
        {
            Name = name;
            Endurance = endurance;
            Sprint = sprint;
            Dribble = dribble;
            Passing = passing;
            Shooting = shooting;
        }
        public string Name { get => name; set { if (string.IsNullOrEmpty(value)) { throw new Exception("A name should not be empty."); } name = value; } }
        public int Endurance { get => endurance; set { if (value < 0 || value > 100) { throw new Exception("Endurance should be between 0 and 100."); } endurance = value; } }
        public int Sprint { get => sprint; set { if (value < 0 || value > 100) { throw new Exception("Sprint should be between 0 and 100."); } sprint = value; } }
        public int Dribble { get => dribble; set { if (value < 0 || value > 100) { throw new Exception("Dribble should be between 0 and 100."); } dribble = value; } }
        public int Passing { get => passing; set { if (value < 0 || value > 100) { throw new Exception("Passing should be between 0 and 100."); } passing = value; } }
        public int Shooting { get => shooting; set { if (value < 0 || value > 100) { throw new Exception("Shooting should be between 0 and 100."); } shooting = value; } }
        public double Rating { get => Rating1(); }
        double Rating1()
        {
            double rating = (endurance + sprint + dribble + passing + shooting) / 5.00;
            return rating;
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {

            string[] teamTokens = Console.ReadLine().Split(";");
            try
            {
                Team team = new(teamTokens[1]);
                string command = Console.ReadLine();
                while (command != "END")
                {
                    try
                    {
                        string[] commandAsAnArray = command.Split(";");
                        switch (commandAsAnArray[0])
                        {
                            case "Add":
                                string club = commandAsAnArray[1];
                                string name = commandAsAnArray[2];
                                int endurance = int.Parse(commandAsAnArray[3]);
                                int sprint = int.Parse(commandAsAnArray[4]);
                                int dribble = int.Parse(commandAsAnArray[5]);
                                int passing = int.Parse(commandAsAnArray[6]);
                                int shooting = int.Parse(commandAsAnArray[7]);
                                Player player = new(name, endurance, sprint, dribble, passing, shooting);
                                team.Add(player, club);
                                break;
                            case "Remove":
                                string club1 = commandAsAnArray[1];
                                string name1 = commandAsAnArray[2];
                                team.Remove(name1, club1);
                                break;
                            case "Rating":
                                string club2 = commandAsAnArray[1];
                                if (club2 == team.Name)
                                {
                                    Console.WriteLine($"{club2} - {team.Rating}");
                                }
                                else
                                {
                                    Console.WriteLine($"Team {club2} does not exist.");
                                }
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    command = Console.ReadLine();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
