﻿using System.Reflection.Metadata.Ecma335;

namespace PersonsInfo
{
    public class Dough
    {
        string flourType;
        string bakingTechnique;
        double weight;
        public Dough(string flourType1, string bakingTechnique1, double weight)
        {
            FlourType = flourType1.ToLower();
            BakingTechnique = bakingTechnique1.ToLower();
            Weight = weight;
        }
        string FlourType { get => flourType; set { if (value != "white" && value != "wholegrain"&& value != "White" && value != "Wholegrain") { throw new ArgumentException("Invalid type of dough."); }flourType = value; } }
        string BakingTechnique { get => bakingTechnique; set { if (value != "crispy" && value != "chewy" && value != "homemade" && value != "Crispy" && value != "Chewy" && value != "Homemade") { throw new ArgumentException("Invalid type of dough."); } bakingTechnique = value; } }
        double Weight { get => weight; set { if (value < 100 || value > 200) { throw new ArgumentException("Dough weight should be in the range [1..200]."); } weight = value; } }
        public double Calories { get => calories(); }
        double calories()
        {
            double calories = weight * 2;
            switch (flourType)
            {
                case "white":
                case "White":
                    calories *= 1.5; break;
                case "wholegrain":
                case "Wholegrain":
                    calories *= 1; break;
            }
            switch (bakingTechnique)
            {
                case "crispy":
                case "Crispy":
                    calories *= 0.9; break;
                case "chewy":
                case "Chewy":
                    calories *= 1.1; break;
                case "homemade":
                case "Homemade":
                    calories *= 1; break;
            }
            return calories;
        }
    }
    public class Topping
    {
        string type;
        double weight;
        string original;
        public Topping(string type, double weight)
        {
            original = type;
            Type = type.ToLower();
            Weight = weight;
        }
        string Type { get => type; set { if (value != "Meat" && value != "Veggies" && value != "Cheese" && value != "Sauce" && value != "meat" && value != "veggies" && value != "cheese" && value != "sauce") { throw new ArgumentException($"Cannot place {original} on top of your pizza."); } type = value; } }
        double Weight { get => weight; set { if (value < 1 || value > 50) { throw new ArgumentException($"{original} weight should be in the range [1..50]."); } weight = value; } }
        public double Calories { get => calories(); }
        double calories()
        {
            double calories = weight * 2;
            switch (type)
            {
                case "meat":
                case "Meat":
                    calories *= 1.2; break;
                case "veggies":
                case "Veggies":
                    calories *= 0.8; break;
                case "cheese":
                case "Cheese":
                    calories *= 1.1; break;
                case "sauce":
                case "Sauce":
                    calories *= 0.9; break;
            }
            return calories;
        }
    }
    public class Pizza
    {
        string name;
        Dough dough;
        List<Topping> toppings;
        public Pizza(string name,Dough dough)
        {
            Name = name;
            this.dough = dough;
            toppings = new List<Topping>();
        }
        public string Name { get => name; set { if (string.IsNullOrEmpty(value)|| value.Length < 1 || value.Length > 15) { throw new ArgumentException("Pizza name should be between 1 and 15 symbols."); } name = value; } }
        public int Toppings { get => toppings.Count; }
        public double TotalCalories { get => totalCalories(); }
        double totalCalories()
        {
            double totalCalories = 0;
            foreach (var item in toppings)
            {
                totalCalories += item.Calories;
            }
            return totalCalories + dough.Calories;
        }
        public void Add(Topping topping)
        {
            if (Toppings < 10)
            {
                toppings.Add(topping);
            }
            else
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }
            
        }

    }

    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] pizzaTokens = Console.ReadLine().Split();
            string[] doughTokens = Console.ReadLine().Split();
            try
            {
                Dough dough = new(doughTokens[1], doughTokens[2], double.Parse(doughTokens[3]));
                Pizza pizza = new(pizzaTokens[1], dough);
                string command = Console.ReadLine();
                while (command != "END")
                {
                    string[] commandAsAnArray = command.Split();
                    Topping topping = new(commandAsAnArray[1], double.Parse(commandAsAnArray[2]));
                    pizza.Add(topping);
                    command = Console.ReadLine();
                }
                Console.WriteLine($"{pizzaTokens[1]} - {pizza.TotalCalories:f2} Calories.");
            }
            catch(ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }
           
        }
    }
}
