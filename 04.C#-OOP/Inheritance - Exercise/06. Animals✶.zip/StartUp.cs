﻿using System;
using System.Reflection;
using System.Xml.Linq;

namespace Animals
{
    public class Animal
    {
        public Animal(string name, int age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public virtual string ProduceSound()
        {
            return null;
        }
    }
    public class Dog : Animal
    {
        public Dog(string name, int age, string gender) : base(name, age, gender)
        {
        }
        public override string ProduceSound() =>  "Woof!";
    }
    public class Cat : Animal
    {
        public Cat(string name, int age, string gender) : base(name, age, gender)
        {
        }
        public override string ProduceSound() => ("Meow meow");
    }
    public class Frog : Animal
    {
        public Frog(string name, int age, string gender) : base(name, age, gender)
        {
        }
        public override string ProduceSound() => ("Ribbit");
    }
    public class Kitten : Cat
    {
        public Kitten(string name, int age) : base(name, age, "Female")
        {
        }
        public override string ProduceSound() => ("Meow");
    }
    public class Tomcat : Cat
    {
        public Tomcat(string name, int age) : base(name, age, "Male")
        {
        }
        public override string ProduceSound() => ("MEOW");
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string command = Console.ReadLine();
            string currAnimal = String.Empty;
            int counter = 0;
            while (command != "Beast!")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (counter % 2 != 0)
                {
                    bool temp = false;
                    if (tokens.Length == 3)
                    {
                        string name = tokens[0];
                        int age = int.Parse(tokens[1]);
                        string gender = tokens[2];
                        if (string.IsNullOrWhiteSpace(name) || age < 0)
                        {
                            Console.WriteLine("Invalid input!");
                            temp = true;

                        }
                        if (string.IsNullOrWhiteSpace(gender))
                        {
                            if (currAnimal != "Tomcat" && currAnimal != "Kitten")
                            {
                                Console.WriteLine("Invalid input!");
                                temp = true;
                            }
                        }
                        if (temp == false)
                        {
                            switch (currAnimal)
                            {
                                case "Dog": Dog dog = new(name, age, gender); Console.WriteLine("Dog"); Console.WriteLine($"{name} {age} {gender}"); Console.WriteLine(dog.ProduceSound());  break;
                                case "Cat": Cat cat = new(name, age, gender); Console.WriteLine("Cat"); Console.WriteLine($"{name} {age} {gender}"); Console.WriteLine(cat.ProduceSound()); break;
                                case "Frog": Frog frog = new(name, age, gender); Console.WriteLine("Frog"); Console.WriteLine($"{name} {age} {gender}"); Console.WriteLine(frog.ProduceSound()); break;
                                case "Kitten": Kitten kitten = new(name, age); Console.WriteLine("Kitten"); Console.WriteLine($"{name} {age}"); Console.WriteLine(kitten.ProduceSound()); break;
                                case "Tomcat": Tomcat tomcat = new(name, age); Console.WriteLine("Tomcat"); Console.WriteLine($"{name} {age}"); Console.WriteLine(tomcat.ProduceSound()); ; break;
                            }
                        }
                    }
                    else if (tokens.Length == 2)
                    {
                        string name = tokens[0];
                        int age = int.Parse(tokens[1]);
                        if (string.IsNullOrWhiteSpace(name) || age < 0)
                        {
                            Console.WriteLine("Invalid input!");
                            temp = true;

                        }

                        if (temp == false)
                        {
                            switch (currAnimal)
                            {
                                case "Kitten": Kitten kitten = new(name, age); Console.WriteLine("Kitten"); Console.WriteLine($"{name} {age}"); kitten.ProduceSound(); break;
                                case "Tomcat": Tomcat tomcat = new(name, age); Console.WriteLine("Tomcat"); Console.WriteLine($"{name} {age}"); tomcat.ProduceSound(); break;
                            }
                        }
                    }

                }
                else
                {
                    currAnimal = tokens[0];
                }
                command = Console.ReadLine();
                counter++;
            }
        }
    }
}

