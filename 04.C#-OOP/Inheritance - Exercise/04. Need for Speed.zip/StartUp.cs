﻿using System;

namespace NeedForSpeed
{
    public class Vehicle
    {
        public Vehicle(int horsePower, double fuel)
        {
            HorsePower = horsePower;
            Fuel = fuel;
        }
        double DefaultFuelConsumption = 1.25;
         public virtual double FuelConsumption { get { return DefaultFuelConsumption; } set { DefaultFuelConsumption = value; } }
        public double Fuel { get; set; }
        public int HorsePower { get; set; }
        public virtual void Drive(double kilometers)
        {
            Fuel -= FuelConsumption * kilometers;
        }
    }
    public class Motorcycle : Vehicle
    {
        public Motorcycle(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
    public class Car : Vehicle
    {
        public override double FuelConsumption => 3;
        public Car(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
        
    }
    public class RaceMotorcycle : Motorcycle
    {
        public override double FuelConsumption => 8;
        public RaceMotorcycle(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
    public class CrossMotorcycle : Motorcycle
    {
        public CrossMotorcycle(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
    public class FamilyCar : Car
    {
        public FamilyCar(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
    public class SportCar : Car
    {
        public override double FuelConsumption => 10;

        public SportCar(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SportCar car = new(100, 100);
            car.Drive(20);
            Console.WriteLine(car.Fuel);
        }
    }
}
