using NUnit.Framework;

namespace RobotFactory.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void CtorForFactorySetsValuesCorrectly()
        {
            Factory factory = new Factory("Pesho", 100);

            Assert.That("Pesho", Is.EqualTo(factory.Name));
            Assert.That(100, Is.EqualTo(factory.Capacity));
            Assert.That(factory.Robots.Count == 0);
            Assert.That(factory.Supplements.Count == 0);
        }
        [Test]
        public void CtorForRobotSetsValuesCorrectly()
        {
            Robot robot = new("Kur", 69, 420);
            Assert.That(robot.Model == "Kur");
            Assert.That(robot.Price == 69);
            Assert.That(robot.InterfaceStandard == 420);
        }
        [Test]
        public void ProduceRobotProducesRobotsCorrectlyIfItIsntFull()
        {
            Factory factory = new("Pesho", 10);
           
            string output = factory.ProduceRobot("Kur", 69, 420);
            string expectedOutput = $"Produced --> Robot model: Kur IS: 420, Price: 69.00";

            Assert.That(expectedOutput, Is.EqualTo(output));
            Assert.That(factory.Robots.Count, Is.EqualTo(1));
        }
        [Test]
        public void ProduceRobotShouldNotProduceIfItIsFull()
        {
            Factory factory = new("Pesho", 0);

            string output = factory.ProduceRobot("Kur", 69, 420);
            string expectedOutput = "The factory is unable to produce more robots for this production day!";

            Assert.That(expectedOutput, Is.EqualTo(output));
            Assert.That(factory.Robots.Count, Is.EqualTo(0));
        }
        [Test]
        public void ProduceSupplementWorks()
        {
            Factory factory = new("Pesho", 4);

            string output=factory.ProduceSupplement("Gosho", 420);
            string expected = "Supplement: Gosho IS: 420";

            Assert.That(output == expected);
            Assert.That(factory.Supplements.Count, Is.EqualTo(1));
        }
        [Test]
        public void CtorForSupplementSetsValuesCorrectly()
        {
            Supplement supplement = new("Gosho", 420);

            Assert.That(supplement.Name == "Gosho");
            Assert.That(supplement.InterfaceStandard == 420);
        }
        [Test]
        public void UpgradeRobotDoesNotUpgradeIfThereIsSupplementAlready()
        {
            Robot robot = new("Gosho",69, 420);
            Supplement supplement = new("Pesho", 421);
            Factory factory = new("Pisho", 69);

            bool output = factory.UpgradeRobot(robot, supplement);
            bool expected = false;
            
            Assert.That(output, Is.EqualTo(expected));
        }
        [Test]
        public void UpgradeRobotWorksCorrectlyIfEverythingIsOk()
        {
            Robot robot = new("Gosho", 69, 420);
            Supplement supplement = new("Pesho", 420);
            Factory factory = new("Pisho", 69);

            bool output = factory.UpgradeRobot(robot, supplement);
            bool expected = true;

            Assert.That(output, Is.EqualTo(expected));
            Assert.That(robot.Supplements.Count, Is.EqualTo(1));
        }
        [Test]
        public void SellRobotGivesTheFirstRobotWhichPriceIsLessThatTheGivenOne()
        {
            Factory factory = new("Gosho", 100);
            for (int i = 1; i < 10; i++)
            {
                Robot robot = new("Pesho", i, 420);
                factory.Robots.Add(robot);
            }
            Robot robot1 = factory.SellRobot(5);

            string expected = "Robot model: Pesho IS: 420, Price: 5.00";
            string output = robot1.ToString();

            Assert.That(expected == output);
        }
    }
}