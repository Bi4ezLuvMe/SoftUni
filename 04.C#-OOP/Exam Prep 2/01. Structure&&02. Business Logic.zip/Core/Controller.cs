﻿using RobotService.Core.Contracts;
using RobotService.Models;
using RobotService.Models.Contracts;
using RobotService.Repositories;
using RobotService.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotService.Core
{
    public class Controller : IController
    {
        SupplementRepository supplements;
        RobotRepository robots;
        public Controller()
        {
            supplements=new SupplementRepository();
            robots=new RobotRepository();
        }
        public string CreateRobot(string model, string typeName)
        {
            if (typeName == "DomesticAssistant")
            {
                IRobot robot = new DomesticAssistant(model);
                robots.AddNew(robot);
            }
            else if (typeName == "IndustrialAssistant")
            {
                IRobot robot = new IndustrialAssistant(model);
                robots.AddNew(robot);
            }
            else
            {
                return $"Robot type {typeName} cannot be created.";
            }
            return $"{typeName} {model} is created and added to the RobotRepository.";
        }

        public string CreateSupplement(string typeName)
        {
            if (typeName == "SpecializedArm")
            {
                ISupplement supplement = new SpecializedArm();
                supplements.AddNew(supplement);
            }
            else if (typeName == "LaserRadar")
            {
                ISupplement supplement = new LaserRadar();
                supplements.AddNew(supplement);
            }
            else
            {
                return $"{typeName} is not compatible with our robots.";
            }
            return $"{typeName} is created and added to the SupplementRepository.";
        }

        public string PerformService(string serviceName, int intefaceStandard, int totalPowerNeeded)
        {
            List<IRobot> robot1 = robots.Models().ToList();
            List<IRobot> selectedRobots = robot1.Where(x => x.InterfaceStandards.Any(y=>y==intefaceStandard)).ToList();
            if (selectedRobots.Count()==0)
            {
                return $"Unable to perform service, {intefaceStandard} not supported!";
            }
            selectedRobots=selectedRobots.OrderByDescending(x=>x.BatteryLevel).ToList();
            int sum = selectedRobots.Sum(x=>x.BatteryLevel);
            if (sum < totalPowerNeeded)
            {
                return $"{serviceName} cannot be executed! {totalPowerNeeded - sum} more power needed.";
            }
            int usedRobotsCount = 0;

            foreach (var robot in selectedRobots)
            {
                usedRobotsCount++;

                if (totalPowerNeeded <= robot.BatteryLevel)
                {
                    robot.ExecuteService(totalPowerNeeded);
                    break;
                }
                else
                {
                    totalPowerNeeded -= robot.BatteryLevel;
                    robot.ExecuteService(robot.BatteryLevel);
                }
            }
            return $"{serviceName} is performed successfully with {usedRobotsCount} robots.";
        }

        public string Report()
        {
            StringBuilder sb = new();
            List<IRobot> allRobots = robots.Models().ToList();
            foreach (var robot in allRobots.OrderByDescending(x=>x.BatteryLevel).ThenBy(x=>x.BatteryCapacity))
            {
                sb.AppendLine(robot.ToString());
            }
            return sb.ToString().TrimEnd();
        }

        public string RobotRecovery(string model, int minutes)
        {
            List<IRobot> robotsToBeFed = robots.Models().Where(x=>x.Model==model&& x.BatteryLevel * 2 < x.BatteryCapacity).ToList();
            int count = 0;
            foreach (var robot in robotsToBeFed)
            {
                robot.Eating(minutes);
                count++;
            }
            return $"Robots fed: {count}";
        }

        public string UpgradeRobot(string model, string supplementTypeName)
        {
            ISupplement supplement = supplements.Models().FirstOrDefault(x=>x.GetType().Name==supplementTypeName);
            var selectedModels = robots.Models().Where(x => x.Model == model);
            var stillNotUpgraded = selectedModels.Where(r => r.InterfaceStandards.All(s => s != supplement.InterfaceStandard));
            var robotForUpgrade = stillNotUpgraded.FirstOrDefault();
            if(robotForUpgrade == null) 
            {
                return $"All {model} are already upgraded!";
            }
            robotForUpgrade.InstallSupplement(supplement);
            supplements.RemoveByName(supplementTypeName);
            return $"{model} is upgraded with {supplementTypeName}.";
        }
    }
}
