﻿using RobotService.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotService.Models.Contracts
{
    public abstract class Robot : IRobot
    {
        string model;
        int batteryCapacity;
        int convertionCapacityIndex;
        int batteryLevel;
        List<int> interfaceStandards;
        public Robot(string model, int batteryCapacity, int conversionCapacityIndex)
        {
            Model = model;
            BatteryCapacity = batteryCapacity;
            convertionCapacityIndex = conversionCapacityIndex;
            batteryLevel = batteryCapacity;
            interfaceStandards = new List<int>();
        }
        public string Model 
        { 
            get => model;
            private set 
            { 
                if (String.IsNullOrWhiteSpace(value)) 
                { 
                    throw new ArgumentException(ExceptionMessages.ModelNullOrWhitespace); 
                }
                model = value;
            }
        }

        public int BatteryCapacity
        {
            get => batteryCapacity;
            private set
            {
                if (value<0)
                {
                    throw new ArgumentException(ExceptionMessages.BatteryCapacityBelowZero);
                }
                batteryCapacity = value;
            }
        }

        public int BatteryLevel
        {
            get => batteryLevel;
        }

        public int ConvertionCapacityIndex
        {
            get => convertionCapacityIndex;
        }

        public IReadOnlyCollection<int> InterfaceStandards { get => interfaceStandards;  }

        public void Eating(int minutes)
        {
            int energy = convertionCapacityIndex * minutes;
            if (energy > BatteryCapacity - BatteryLevel)
            {
                batteryLevel = batteryCapacity;
            }
            else
            {
                batteryLevel += energy;
            }
        }

        public bool ExecuteService(int consumedEnergy)
        {
            if (consumedEnergy <= this.batteryLevel)
            {
                batteryLevel-= consumedEnergy;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void InstallSupplement(ISupplement supplement)
        {
            interfaceStandards.Add(supplement.InterfaceStandard);
            batteryCapacity -= supplement.BatteryUsage;
            batteryLevel -= supplement.BatteryUsage;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this.GetType().Name} {this.Model}:");
            sb.AppendLine($"--Maximum battery capacity: {this.BatteryCapacity}");
            sb.AppendLine($"--Current battery level: {this.BatteryLevel}");
            sb.Append($"--Supplements installed: ");

            if (this.InterfaceStandards.Count == 0)
            {
                sb.Append("none");
            }
            else
            {
                sb.Append(string.Join(" ", this.InterfaceStandards));
            }

            return sb.ToString().TrimEnd();
        }
    }
}
