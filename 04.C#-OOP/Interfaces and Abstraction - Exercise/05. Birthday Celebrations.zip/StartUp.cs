﻿using System;

namespace PersonInfo
{
    abstract class Inhabitant
    {
        public Inhabitant(string name)
        {
            this.Name = name;

        }

        public abstract string Name { get; set; }
    }

    interface IAge
    {
        int Age { get; set; }
    }

    interface IId
    {
        string Id { get; set; }
    }

    interface IBirthDate
    {
        string BirthDate { get; set; }
    }

    class Citizen : Inhabitant, IAge, IId, IBirthDate
    {

        public Citizen(string name, int age,string id, string birthDate) : base(name)
        {
            this.Id = id;
            this.Age = age;
            this.BirthDate = birthDate;
        }
        public override string Name { get; set; }
        public string Id { get; set; }
        public int Age { get; set; }
        public string BirthDate { get; set; }
    }

    class Robot : Inhabitant, IId
    {
        public Robot(string name, string id) : base(name)
        {
            this.Id = id;
        }

        public override string Name { get; set; }
        public string Id { get; set; }
    }

    class Pet : Inhabitant, IBirthDate
    {
        public Pet(string name, string birthDate) : base(name)
        {
            this.BirthDate = birthDate;
        }

        public override string Name { get; set; }
        public string BirthDate { get; set; }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<string>Birthdays = new();
            while (command != "End")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens[0] == "Citizen")
                {
                    Citizen person = new Citizen(tokens[1], int.Parse(tokens[2]), tokens[3], tokens[4]);
                    Birthdays.Add(person.BirthDate);
                }
                else if (tokens[0] == "Pet")
                {
                   Pet pet = new Pet(tokens[1], tokens[2]);
                    Birthdays.Add(pet.BirthDate);
                }
                command = Console.ReadLine();
            }
            string wanted = (Console.ReadLine());
            foreach (var item in Birthdays)
            {
                string[] year = item.Split("/");
                if (year[2] == wanted)
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
