﻿using System.Reflection.Metadata.Ecma335;

namespace PersonInfo
{
   public interface IDialable
    {
        void Call();
    }
    public interface ISurfable 
    {
        void Surf();
    }
    public class Stationary:IDialable
    {
        string phoneNumber;
        public Stationary(string phoneNumber)
        {
            PhoneNumber = phoneNumber;
        }
        public string PhoneNumber { get => phoneNumber; set { if (value.Any(char.IsLetter)) { throw new Exception("Invalid number!"); }phoneNumber = value; } }
        void IDialable.Call()
        {
            if(phoneNumber is not null)
            {
                if (phoneNumber.Length == 10)
                {
                    Console.WriteLine($"Calling... {phoneNumber}");
                }else if(phoneNumber.Length == 7)
                {
                    Console.WriteLine($"Dialing... {phoneNumber}");
                }
            }
        }
    }
    public class Smartphone : ISurfable
    {
        string _URL;
        public Smartphone(string URL)
        {
            this.URL = URL;
        }
        public string URL { get => _URL; set { if (value.Any(char.IsDigit)) { throw new Exception("Invalid URL!"); }_URL = value; } }
        void ISurfable.Surf()
        {
            Console.WriteLine($"Browsing: {_URL}!");
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] phoneNumbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] URLs = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            foreach (var item in phoneNumbers)
            {
                try
                {
                    IDialable number = new Stationary(item);
                    number.Call();
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            foreach (var item in URLs)
            {
                try
                {
                    ISurfable url = new Smartphone(item);
                    url.Surf();
                }catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
