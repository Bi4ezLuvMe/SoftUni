﻿namespace PersonInfo
{

    interface ICitizen
    {
        string Name { get; set; }
        string Id { get; set; }
        int Age { set; get; }
        string BirthDate { get; set; }
        interface IBuyer
        {
            int BuyFood();
        }
    }
    interface IRebel
    {
        string Name { get; set; }
        int Age { get ; set; }
        string Group { get; set; }
        interface IBuyer
        {
            int BuyFood();
        }
    }
    class Citizen : ICitizen.IBuyer,ICitizen
    {

        public Citizen(string name, int age, string id, string birthDate)
        {
            this.Id = id;
            this.Age = age;
            this.BirthDate = birthDate;
        }
        public int Food { get { return Food; } private set { Food = 0; } }
        public string Name { get; set; }
        public string Id { get; set; }
        public int Age { get; set; }
        public string BirthDate { get; set; }
        int ICitizen.IBuyer.BuyFood()
        {
            return 10;
        }
    }
    class Rebel : IRebel,IRebel.IBuyer
    {
        public Rebel(string name, int age, string group)
        {
            Name = name;
            Age = age;
            Group = group;
        }
        public int Food { get { return Food; } private set { Food = 0; } }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Group { get; set; }
        int IRebel.IBuyer.BuyFood()
        {
            return 5;
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Dictionary<IRebel.IBuyer,string> rebels = new();
            Dictionary<ICitizen.IBuyer,string> humans = new();
            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length == 3)
                {
                    Rebel rebel = new(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    rebels.Add(rebel, tokens[0]);
                }
                else if (tokens.Length == 4)
                {
                    Citizen citizen = new(tokens[0], int.Parse(tokens[1]), tokens[2], tokens[3]);
                    humans.Add(citizen, tokens[0]);
                }
            }
            string command = Console.ReadLine();
            int food = 0;
            while (command != "End")
            {
                foreach (var item in rebels)
                {
                    if (item.Value == command)
                    {
                        food+=item.Key.BuyFood();
                    }
                }
                foreach (var item in humans)
                {
                    if (item.Value == command)
                    {
                        food+=item.Key.BuyFood();
                    }
                }
                command = Console.ReadLine();
            }
            Console.WriteLine(food);
        }
    }
}
