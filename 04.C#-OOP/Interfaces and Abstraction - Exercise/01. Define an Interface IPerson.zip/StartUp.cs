﻿using System.Reflection.Metadata.Ecma335;

namespace PersonInfo
{
    public interface IPerson
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
    public class Citizen:IPerson
    {
        string name;
        int age;
        public Citizen(string name,int age)
        {
            Name = name;
            Age = age;
        }
        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string name = Console.ReadLine();
            int age = int.Parse(Console.ReadLine());
            IPerson person = new Citizen(name, age);
            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);
        }
    }
}
