﻿using System.Reflection.Metadata.Ecma335;

namespace PersonInfo
{
   public interface ICitizen
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Id { get; set; }
    }
    public interface IRobot 
    {
        public string Model { get; set; }
        public string Id { get; set; }
    }
    public class Citizen : ICitizen
    {
        string name;
        int age;
        string id;
        public Citizen(string name, int age, string id)
        {
            Name = name;
            Age = age;
            Id = id;
        }
        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
        public string Id { get => id; set => id = value; }
    }
    public class Robot : IRobot
    {
        string model;
        string id;
        public Robot(string model, string id)
        {
            Model = model;
            Id = id;
        }
        public string Model { get => model; set => model = value; }
        public string Id { get => id; set => id = value; }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<string> IDs = new();
            while (command != "End")
            {
                string[] tokens = command.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if(tokens.Length == 3)
                {
                    ICitizen person = new Citizen(tokens[0], int.Parse(tokens[1]), tokens[2]);
                    IDs.Add(person.Id);
                }
                else if (tokens.Length==2)
                {
                    IRobot robot = new Robot(tokens[0], tokens[1]);
                    IDs.Add(robot.Id);
                }
                command = Console.ReadLine();
            }
            string wanted =(Console.ReadLine());
            foreach (var item in IDs)
            {
                if (item.EndsWith(wanted))
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}
