﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void CtorShouldInitializeCorrectly()
        {
            Dummy dummy = new(10, 10);

            Assert.That(dummy.Health, Is.EqualTo(10));
        }
        [Test]
        public void DummyLossesHealthIfAttacked()
        {
            Dummy dummy = new(10, 10);

            dummy.TakeAttack(1);

            Assert.That(dummy.Health==9);
        }
        [Test]
        public void DeadDummyThrowsExceptionIfAttacked()
        {
            Dummy dummy = new(1, 10);

            dummy.TakeAttack(1);

            Assert.Throws<InvalidOperationException>(()=>dummy.TakeAttack(1),"Dummy is dead.");
        }
        [Test]
        public void AliveDummyCantGiveXP()
        {
            Axe axe = new(1, 10);
            Dummy dummy = new(2, 10);

            axe.Attack(dummy);

            Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience(),"Target is not dead.");
        }
        [Test]
        public void DeadDummyCanGiveXP() 
        {
            Axe axe = new(1, 10);
            Dummy dummy = new(1, 10);

            axe.Attack(dummy);

            Assert.DoesNotThrow(()=>dummy.GiveExperience(), "Target is not dead.");
        }
        [Test]
        public void DummyIsDeadIfHealthIsBelowOrEqualToZero()
        {
            Axe axe = new(1, 10);
            Dummy dummy = new(1, 10);

            axe.Attack(dummy);

            Assert.That(dummy.IsDead());
        }
    }
}