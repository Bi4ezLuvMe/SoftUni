using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void AxeLossesDurabilityAfterAttack()
        {
            Axe axe = new(10, 10);
            Dummy dummy = new(100, 100);

            axe.Attack(dummy);

            Assert.That(axe.DurabilityPoints, Is.EqualTo(9),"Axe Durability doesn't change after attack.");
        }
        [Test]
        public void AxeCantAttackWithBrokenWepon()
        {
            Axe axe = new(10, 1);
            Dummy dummy = new(100, 100);

            axe.Attack(dummy);

            Assert.Throws<InvalidOperationException>(()=> axe.Attack(dummy), "Axe is broken.");
        }
    }
}