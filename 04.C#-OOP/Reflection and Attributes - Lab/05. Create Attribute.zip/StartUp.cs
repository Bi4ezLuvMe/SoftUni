﻿using System.Reflection;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace AuthorProblem
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method,AllowMultiple =true)]
    public class AuthorAttribute:Attribute
    {
        public AuthorAttribute(string name)
        {
            Name = name;
        }
        public string Name { get; set; }
    }
    [Author("Victor")]
    public class StartUp
    {
        [Author("George")]
        static void Main(string[] args)
        {
         
        }
    }
}