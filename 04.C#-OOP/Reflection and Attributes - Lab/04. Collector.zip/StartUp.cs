﻿using System.Reflection;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace Stealer
{
    public class Hacker
    {
        public string username = "securityGod82";
        private string password = "mySuperSecretPassw0rd";
        public string Password
        {
            get => this.password;
            set => this.password = value;
        }
        private int Id { get; set; }
        public double BankAccountBalance { get; private set; }
        public void DownloadAllBankAccountsInTheWorld()
        {
        }
    }
    public class Spy
    {
        public string StealFieldInfo(string name, string[] fields)
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine($"Class under investigation: {name}");
            Type type = typeof(Hacker);
            Hacker hacker = (Hacker)Activator.CreateInstance(type);
            FieldInfo[] info = type.GetFields((BindingFlags)60);
            stringBuilder.AppendLine($"username = {info[0].GetValue(hacker)}");
            stringBuilder.AppendLine($"password = {info[1].GetValue(hacker)}");
            return stringBuilder.ToString().TrimEnd();
        }
        public string AnalyzeAccessModifiers(string className)
        {
            StringBuilder stringBuilder = new StringBuilder();
            Type type = typeof(Hacker);
            FieldInfo[] fields = type.GetFields((BindingFlags)60);
            MethodInfo[]classPublicMethods = type.GetMethods(BindingFlags.Instance|BindingFlags.Public);
            MethodInfo[] classNonPublicMethods = type.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);
            foreach (var item in fields.Where(x=>!x.IsPrivate))
            {
                    stringBuilder.AppendLine($"{item.Name} must be private!");
            }
            foreach (var item in classPublicMethods.Where(x=>x.Name.StartsWith("set")))
            {
                stringBuilder.AppendLine($"{item.Name} have to be private!");
            }
            foreach (var item in classNonPublicMethods.Where(x => x.Name.StartsWith("get")))
            {
                stringBuilder.AppendLine($"{item.Name} have to be public!");
            }
            return stringBuilder.ToString().TrimEnd();
        }
        public string RevealPrivateMethods(string className)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"All Private Methods of Class: {className}");
            Type type = Type.GetType(className);
            sb.AppendLine($"Base Class: {type.BaseType.Name}");
            MethodInfo[] infos = type.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);
            foreach (var item in infos)
            {
                sb.AppendLine(item.Name);
            }
            return sb.ToString().TrimEnd();
        }
        public string CollectGettersAndSetters(string className)
        {
            StringBuilder sb = new StringBuilder();
            Type type = Type.GetType(className);
            MethodInfo[] info = type.GetMethods((BindingFlags)60);
            foreach (var item in info.Where(x => x.Name.StartsWith("get")))
            {
                sb.AppendLine($"{item.Name} will return {item.ReturnType}");
            }
            foreach (var item in info.Where(x => x.Name.StartsWith("set")))
            {
                sb.AppendLine($"{item.Name} will set field of {item.GetParameters().First().ParameterType}");
            }
            return sb.ToString().TrimEnd();
        }
    }
    public class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new();
            string result = spy.CollectGettersAndSetters("Stealer.Hacker");
            Console.WriteLine(result);
        }
    }
}