﻿using System.Reflection;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace AuthorProblem
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method,AllowMultiple =true)]
    public class AuthorAttribute:Attribute
    {
        public AuthorAttribute(string name)
        {
            Name = name;
        }
        public string Name { get; set; }
    }
    public class Tracker
    {
        public void PrintMethodsByAuthor()
        {
            Type types = typeof(StartUp);
            MethodInfo[]methods = types.GetMethods((BindingFlags)60);
            foreach (MethodInfo method in methods)
            {
                if(method.CustomAttributes.Any(x=>x.AttributeType == typeof(AuthorAttribute)))
                {
                    AuthorAttribute[] attributes =method.GetCustomAttributes<AuthorAttribute>().ToArray();
                    foreach (AuthorAttribute attribute in attributes)
                    {
                        Console.WriteLine($"{method.Name} is written by {attribute.Name}");
                    }
                }
            }
        }
    }
    [Author("Victor")]
    public class StartUp
    {
        [Author("George")]
        static void Main(string[] args)
        {
         Tracker tracker = new Tracker();
            tracker.PrintMethodsByAuthor();
        }
    }
}