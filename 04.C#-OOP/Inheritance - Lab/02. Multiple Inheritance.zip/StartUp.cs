﻿namespace Farm
{
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
    class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
    class Puppy:Dog
    {
        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Puppy dog = new();
            dog.Bark();
            dog.Eat();
            dog.Weep();
        }
    }
}
