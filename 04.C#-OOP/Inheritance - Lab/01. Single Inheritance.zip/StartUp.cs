﻿namespace Farm
{
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
    class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Dog dog = new();
            dog.Bark();
            dog.Eat();
        }
    }
}
