﻿using CommandPattern.Core.Commands;
using CommandPattern.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandPattern.Core
{
    public class CommandInterpreter : ICommandInterpreter
    {
        public string Read(string args)
        {
            string[]tokens = args.Split(' ');
            string result = null;
            if (tokens[0]=="Hello")
            {
                Type type = typeof(HelloCommand);
                ICommand commandInstance = Activator.CreateInstance(type) as ICommand;
                tokens[0] = tokens[1];
                result = commandInstance.Execute(tokens);
            }
            else if (tokens[0]=="Exit")
            {
                Type type = typeof(ExitCommand);
                ICommand commandInstance = Activator.CreateInstance(type) as ICommand;
                result = commandInstance.Execute(tokens);

            }
            return result;
        }
    }
}
