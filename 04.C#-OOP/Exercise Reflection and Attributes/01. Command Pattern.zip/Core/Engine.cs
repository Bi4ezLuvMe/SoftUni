﻿using CommandPattern.Core.Commands;
using CommandPattern.Core.Contracts;
using System;

namespace CommandPattern.Core
{
    public class Engine : IEngine
    {
        private readonly ICommandInterpreter commandInterpreter;
        public Engine(ICommandInterpreter commandInterpreter)
        {
            this.commandInterpreter = commandInterpreter;
        }
        public void Run()
        {
            while (true)
            {
                string command = Console.ReadLine();
                if (commandInterpreter.Read(command) == null)
                {
                    Console.WriteLine("Wrong input!");
                    continue;
                }
                Console.WriteLine(commandInterpreter.Read(command));
            }
        }
    }
}
