﻿using System;
using System.Linq;
using System.Reflection;

namespace ValidationAttributes
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var person = new Person
             (
                 "Ivancho",
                 18
             );

            bool isValidEntity = Validator.IsValid(person);

            Console.WriteLine(isValidEntity);
        }
    }

    public class Person
    {
        private const int minAge = 12;
        private const int maxAge = 90;

        public Person(string fullName, int age)
        {
            FullName = fullName;
            Age = age;
        }
        [MyRequired]
        public string FullName { get;private set; }
        [MyRange(minAge,maxAge)]
        public int Age { get; private set; }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public abstract class MyValidationAttribute : Attribute
    {
        public abstract bool IsValid(object obj);
    } 
    public class MyRangeAttribute : MyValidationAttribute
    {
        private int minAge;
        private int maxAge;
        public MyRangeAttribute(int minAge,int maxAge)
        {
            this.maxAge = maxAge;
            this.minAge = minAge;
        }
        public override bool IsValid(object obj)
        => (int)obj>=minAge&&(int)obj<=maxAge;
    }
    public class MyRequiredAttribute : MyValidationAttribute
    {
        public override bool IsValid(object obj)
        => obj is not null;
    }
    public static class Validator 
    {

        public static bool IsValid(object obj)
        {
            Type type = obj.GetType();
            PropertyInfo[] info = type.GetProperties()
                .Where(x=>x.CustomAttributes
                .Any(x=>typeof(MyValidationAttribute).IsAssignableFrom(x.AttributeType)))
                .ToArray();
            foreach (var item in info)
            {
                MyValidationAttribute[] attributes = item.GetCustomAttributes()
                    .Where(x => typeof(MyValidationAttribute)
                    .IsAssignableFrom(x.GetType()))
                    .Cast<MyValidationAttribute>()
                    .ToArray();
                foreach (var attribute in attributes)
                {
                    if (!attribute.IsValid(item.GetValue(obj)))
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }

}
