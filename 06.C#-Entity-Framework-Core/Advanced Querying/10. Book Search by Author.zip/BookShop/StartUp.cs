﻿namespace BookShop
{
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            string input = (Console.ReadLine());
            Console.WriteLine(GetBooksByAuthor(db, input));
        }
        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            StringBuilder sb = new();
           var books = context.Books.OrderBy(x => x.BookId).Select(x => new
           {
               BookTitle = x.Title,
               AuthorLastName = x.Author.LastName,
               AuthorName = x.Author.FirstName+" "+x.Author.LastName
           });
            foreach (var book in books)
            {
                if (book.AuthorLastName.ToLower().StartsWith(input.ToLower()))
                {
                    sb.AppendLine($"{book.BookTitle} ({book.AuthorName})");
                }
            }
            return sb.ToString().TrimEnd();
        }
    }
}


