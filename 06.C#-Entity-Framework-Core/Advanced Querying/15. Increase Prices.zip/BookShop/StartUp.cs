﻿namespace BookShop
{
    using BookShop.Models;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            //int lengthCheck = int.Parse(Console.ReadLine());
            IncreasePrices(db);
        }
        public static void IncreasePrices(BookShopContext context)
        {
            var books = context.Books.Where(x=>x.ReleaseDate.Value.Year<2010);
            foreach (var book in books)
            {
                book.Price += 5;
            }
        }
    }
}


