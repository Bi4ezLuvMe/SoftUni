﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            //string command = Console.ReadLine();
            Console.WriteLine(GetGoldenBooks(db));
        }
           public static string GetGoldenBooks(BookShopContext context)
           {
            StringBuilder sb = new();
            var books = context.Books.Where(x=>x.Copies<5000).OrderBy(x=>x.BookId);
            foreach (var book in books)
            {
                if (book.EditionType.ToString() == "Gold")
                {
                    sb.AppendLine(book.Title);
                }
            }
            return sb.ToString().TrimEnd();
        }
    }
}


