﻿namespace BookShop
{
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            string input = (Console.ReadLine());
            Console.WriteLine(GetBookTitlesContaining(db, input));
        }
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            StringBuilder sb = new();
            var books = context.Books.Select(x => new
            {
                Title = x.Title
            }).OrderBy(x=>x.Title);
            foreach (var book in books)
            {
                if (book.Title.ToLower().Contains(input.ToLower()))
                {
                    sb.AppendLine(book.Title);
                }
            }
            return sb.ToString().TrimEnd();
        }
    }
}


