﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            string command = Console.ReadLine();
            Console.WriteLine(GetBooksByAgeRestriction(db,command));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder sb = new();
            command = command.ToLower();
            var books = context.Books.OrderBy(x => x.Title).ToList();
            foreach (var book in books)
            {
                string ageRestriction = book.AgeRestriction.ToString().ToLower();
                if (command == ageRestriction)
                {
                    sb.AppendLine(book.Title);
                }
            }
            return sb.ToString().TrimEnd();
        }
    }
}


