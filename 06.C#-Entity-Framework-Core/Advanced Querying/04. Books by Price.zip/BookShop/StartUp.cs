﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            //string command = Console.ReadLine();
            Console.WriteLine(GetBooksByPrice(db));
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new();
            var books = context.Books.Where(x => x.Price > 40).OrderByDescending(x => x.Price);
            foreach (var book in books)
            {
                sb.AppendLine($"{book.Title} - ${book.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}


