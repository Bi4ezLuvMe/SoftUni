﻿namespace BookShop
{
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            string date = (Console.ReadLine());
            Console.WriteLine(GetBooksReleasedBefore(db, date));
        }
        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            StringBuilder sb = new();
            var books = context.Books.OrderByDescending(x => x.ReleaseDate).ToList();
            foreach (var book in books)
            {
                if(book.ReleaseDate < DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture))
                {
                    sb.AppendLine($"{book.Title} - {book.EditionType} - ${book.Price:f2}");
                }
            }
            return sb.ToString().TrimEnd();
        }
    }
}


