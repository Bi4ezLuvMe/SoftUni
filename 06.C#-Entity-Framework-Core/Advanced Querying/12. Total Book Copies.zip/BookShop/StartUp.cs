﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            //int lengthCheck = int.Parse(Console.ReadLine());
            Console.WriteLine(CountCopiesByAuthor(db));
        }
        public static string CountCopiesByAuthor(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            var bookCopiesPerAuthor = context.Authors.OrderByDescending(x => x.Books.Sum(x => x.Copies)).Select(x => new
            {
                AuthorName = x.FirstName +" "+x.LastName,
                TotalCopies = x.Books.Sum(x => x.Copies)
            });
            foreach (var author in bookCopiesPerAuthor)
            {
                sb.AppendLine($"{author.AuthorName} - {author.TotalCopies}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}


