﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            //int lengthCheck = int.Parse(Console.ReadLine());
            Console.WriteLine(GetTotalProfitByCategory(db));
        }
        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            var categories = context.Categories.Select(x => new
            {
                CategoryName = x.Name,
                TotalProfits = x.CategoryBooks.Select(x => x.Book.Copies * x.Book.Price).Sum()
            }).OrderByDescending(x=>x.TotalProfits);
            foreach ( var category in categories )
            {
                sb.AppendLine($"{category.CategoryName} ${category.TotalProfits:f2}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}


