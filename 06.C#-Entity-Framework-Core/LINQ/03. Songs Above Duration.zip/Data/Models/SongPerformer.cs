﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicHub.Data.Models
{
    public class SongPerformer
    {
        [Key]
        public int SongId { get; set; }
        [Key]
        public int PerformerId { get; set; }
        [ForeignKey("SongId")]
        public Song Song { get; set; }
        [ForeignKey("PerformerId")]
        public Performer Performer { get; set; }
    }
}
