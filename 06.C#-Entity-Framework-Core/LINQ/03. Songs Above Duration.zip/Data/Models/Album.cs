﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicHub.Data.Models
{
    public class Album
    {
        public Album()
        {
            Songs = new List<Song>();
        }
        [Key]
        public int Id { get; set; }
        [MaxLength(40),Required]
        public string Name { get; set; }
        [Required]
        public DateTime ReleaseDate { get; set; }
        public decimal Price { get => GetPriceAlbumPrice(Songs); set => value = GetPriceAlbumPrice(Songs); }
        public int? ProducerId { get; set; }
        [ForeignKey("ProducerId")]
        public Producer Producer { get; set; }
        public ICollection<Song> Songs { get; set; }
        static decimal GetPriceAlbumPrice(ICollection<Song>songs)
        {
            decimal price = 0;  
            foreach (var song in songs)
            {
                price += song.Price;
            }
            return price;
        }
    }
}
