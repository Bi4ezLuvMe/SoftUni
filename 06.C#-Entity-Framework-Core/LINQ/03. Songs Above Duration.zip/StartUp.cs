﻿namespace MusicHub
{
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using MusicHub.Data.Models;
    using System;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            DbInitializer.ResetDatabase(context);

            //Test your solutions here
            int seconds = int.Parse(Console.ReadLine());
            Console.WriteLine(ExportSongsAboveDuration(context,seconds));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            StringBuilder sb = new();
            var albums = context.Albums.Where(x => x.ProducerId == producerId).OrderByDescending(x => x.Price).ToList();
            foreach (var album in albums)
            {
                sb.AppendLine($"-AlbumName: {album.Name}");
                sb.AppendLine($"-ReleaseDate: {album.ReleaseDate.ToString("MM/dd/yyyy")}");
                sb.AppendLine($"-ProducerName: {album.Producer.Name}");
                var songs = context.Songs.Where(x => x.Album == album).OrderByDescending(x=>x.Name).ThenBy(x=>x.Writer.Name);
                sb.AppendLine($"-Songs:");
                int counter = 1;
                foreach (var song in songs)
                {
                    sb.AppendLine($"---#{counter}");
                    sb.AppendLine($"---SongName: {song.Name}");
                    sb.AppendLine($"---Price: {song.Price:f2}");
                    sb.AppendLine($"---Writer: {song.Writer.Name}");
                    counter++;
                }
                sb.AppendLine($"-AlbumPrice: {album.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            StringBuilder sb = new();
            int counter = 1;
            var songs = context.Songs.Include(x => x.SongPerformers).Where(x => EF.Functions.DateDiffSecond(TimeSpan.Zero, x.Duration)> duration).OrderBy(x => x.Name).ThenBy(x => x.Writer.Name).ToList();
            foreach (var song in songs)
            {
                sb.AppendLine($"-Song #{counter}");
                sb.AppendLine($"---SongName: {song.Name}");
                sb.AppendLine($"---Writer: {song.Writer.Name}");
                if (song.SongPerformers.Count > 0)
                {
                    sb.AppendLine($"---Performer: {string.Join(", ",song.SongPerformers.OrderBy(x=>x.Performer.FirstName+x.Performer.LastName).Select(x=>x.Performer.FirstName+" "+x.Performer.LastName))}");
                }
                sb.AppendLine($"---AlbumProducer: {song.Album.Producer.Name}");
                sb.AppendLine($"---Duration: {song.Duration.ToString("c")}");
                counter++;
            }
            return sb.ToString().TrimEnd();
        }
    }
}
