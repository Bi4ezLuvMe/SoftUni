﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string IncreaseSalaries(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees
            .Where(x =>
            x.Department.Name == "Engineering" ||
            x.Department.Name == "Tool Design" ||
            x.Department.Name == "Marketing" ||
            x.Department.Name == "Information Services")
            .OrderBy(x => x.FirstName)
            .ThenBy(x => x.LastName);
           
            foreach (var employee in employees)
            {
                employee.Salary *= 1.12M;
                sb.AppendLine($"{employee.FirstName} {employee.LastName} (${employee.Salary:f2})");
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(IncreaseSalaries(context));
        }
    }
}
