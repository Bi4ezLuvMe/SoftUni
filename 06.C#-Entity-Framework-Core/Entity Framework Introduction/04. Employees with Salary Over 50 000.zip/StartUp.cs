﻿using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees.OrderBy(x=>x.FirstName);
            foreach ( var employee in employees )
            {
                if (employee.Salary > 50000)
                {
                    sb.AppendLine($"{employee.FirstName} - {employee.Salary:f2}");
                }
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(GetEmployeesWithSalaryOver50000(context));
        }
    }
}
