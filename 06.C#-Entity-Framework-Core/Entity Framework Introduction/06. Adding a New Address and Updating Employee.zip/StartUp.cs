﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            Address address = new()
            {
                //AddressId = ,
                TownId = 4,
                AddressText = "Vitoshka 15"
        };
            context.Addresses.Add(address);
            context.SaveChanges();
            var employee = context.Employees.Where(x=>x.LastName == "Nakov").FirstOrDefault();
            employee.AddressId = address.AddressId;
            context.SaveChanges();

            var adresses = context.Addresses.OrderByDescending(x => x.AddressId);
            int counter = 0;
            foreach ( var e in adresses)
            {
                if(counter == 10)
                {
                    break;
                }
                sb.AppendLine(e.AddressText);
                counter++;
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(AddNewAddressToEmployee(context));
        }
    }
}
