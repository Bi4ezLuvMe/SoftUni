﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string GetAddressesByTown(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var addresses = context.Addresses.OrderByDescending(x => x.Employees.Count).ThenBy(x => x.Town.Name).ThenBy(x => x.AddressText).Select(x => new
            {
                AddressText = x.AddressText,
                TownName = x.Town.Name,
                EmployeeCount = x.Employees.Count
            });
            int counter = 0;
            foreach ( var address in addresses)
            {
                if (counter == 10)
                {
                    break;
                }
                sb.AppendLine($"{address.AddressText}, {address.TownName} - {address.EmployeeCount} employees");
                counter++;
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(GetAddressesByTown(context));
        }
    }
}
