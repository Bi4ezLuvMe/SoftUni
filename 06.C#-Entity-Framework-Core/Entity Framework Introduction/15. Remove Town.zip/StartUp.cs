﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string RemoveTown(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var townToBeDeleted = context.Towns.FirstOrDefault(x => x.Name == "Seattle");
            context.Towns.Remove(townToBeDeleted);
            var addresses = context.Addresses.Where(x => x.Town.Name == "Seattle");
            int count = 0;
            foreach (var address in addresses)
            {
                context.Addresses.Remove(address);
                count++;
            }
            var employees = context.Employees.Where(x => x.Address.Town.Name == "Seattle");
            foreach (var employee in employees)
            {
                employee.AddressId = null;
            }
            context.SaveChanges();
            sb.AppendLine($"{count} addresses in Seattle were deleted");
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(RemoveTown(context));
        }
    }
}
