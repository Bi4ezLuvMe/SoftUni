﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string GetEmployeesByFirstNameStartingWithSa(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees
                 .Where(x => x.FirstName.StartsWith("Sa"))
                 .OrderBy(x => x.FirstName)
                 .ThenBy(x => x.LastName)
                 .Select(x => new
                 {
                     EmployeeFirstName = x.FirstName,
                     EmployeeLastName = x.LastName,
                     EmployeeJobTitle = x.JobTitle,
                     EmployeeSalary = x.Salary
                 });
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.EmployeeFirstName} {employee.EmployeeLastName} - {employee.EmployeeJobTitle} - (${employee.EmployeeSalary:f2})"); 
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(GetEmployeesByFirstNameStartingWithSa(context));
        }
    }
}
