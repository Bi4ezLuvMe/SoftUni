﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string DeleteProjectById(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var projectToDelete = context.Projects.Find(2); 
            context.Projects.Remove(projectToDelete); 
            context.SaveChanges(); 
            var projects = context.Projects.Take(10).Select(x => new
            {
                ProjectName = x.Name
            });
            foreach (var project in projects)
            {
                sb.AppendLine(project.ProjectName);
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(DeleteProjectById(context));
        }
    }
}
