﻿using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var departments = context.Departments.Where(x => x.Employees.Count > 5).OrderBy(d => d.Employees.Count)
            .ThenBy(d => d.Name).Select(x => new
            {
                DepartmentName = x.Name,
                ManagerFirstName = x.Manager.FirstName,
                ManagerLastName =x.Manager.LastName,
                Employees = x.Employees.OrderBy(x => x.FirstName)
                    .ThenBy(e => e.LastName).Select(x => new
                    {
                        EmployeeFirstName = x.FirstName,
                        EmployeeLastName =x.LastName,
                        JobTitle = x.JobTitle
                    })
            });
            foreach (var department in departments)
            {
                sb.AppendLine($"{department.DepartmentName} - {department.ManagerFirstName} {department.ManagerLastName}");
                foreach (var employee in department.Employees)
                {
                    sb.AppendLine($"{employee.EmployeeFirstName} {employee.EmployeeLastName} - {employee.JobTitle}");
                }
            }
            return sb.ToString().TrimEnd();
        }
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(GetDepartmentsWithMoreThan5Employees(context));
        }
    }
}
