﻿using ProductShop.Data;
using ProductShop.DTOs.Export;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        //1
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(List<ImportUsersDTO>), new XmlRootAttribute("Users"));
            List<ImportUsersDTO> usersDTOs = new List<ImportUsersDTO>();
            List<User> users = new List<User>();
            using (StringReader reader = new(inputXml))
            {
                usersDTOs = (List<ImportUsersDTO>)serializer.Deserialize(reader);
            }
            foreach (var user in usersDTOs)
            {
                User u = new()
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Age = user.Age
                };
                users.Add(u);
            }
            context.Users.AddRange(users);
            context.SaveChanges();
            return $"Successfully imported {users.Count}";
        }
        //2
        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(List<ImportProductsDTO>), new XmlRootAttribute("Products"));
            List<ImportProductsDTO> productsDTOs = new();
            List<Product> products = new List<Product>();
            using (StringReader reader = new(inputXml))
            {
                productsDTOs = (List<ImportProductsDTO>)serializer.Deserialize(reader);
            }
            foreach (var product in productsDTOs)
            {
                Product p = new()
                {
                    Name = product.Name,
                    Price = product.Price,
                    SellerId = product.SellerId,
                    BuyerId = product.BuyerId
                };
                products.Add(p);
            }
            context.Products.AddRange(products);
            context.SaveChanges();
            return $"Successfully imported {products.Count}";
        }
        //3
        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(List<ImportCategoriesDTO>), new XmlRootAttribute("Categories"));
            List<ImportCategoriesDTO> categoriesDTOs = new();
            List<Category> categories = new List<Category>();
            using (StringReader reader = new(inputXml))
            {
                categoriesDTOs = (List<ImportCategoriesDTO>)serializer.Deserialize(reader);
            }
            foreach (var category in categoriesDTOs)
            {
                Category p = new()
                {
                    Name = category.Name,

                };
                categories.Add(p);
            }
            context.Categories.AddRange(categories);
            context.SaveChanges();
            return $"Successfully imported {categories.Count}";
        }
        //4
        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            XmlSerializer serializer = new(typeof(List<ImportCategoriesProductsDTO>), new XmlRootAttribute("CategoryProducts"));
            List<ImportCategoriesProductsDTO> categoryProductsDTOs = new();
            List<CategoryProduct> categoryProduct = new List<CategoryProduct>();
            using (StringReader reader = new(inputXml))
            {
                categoryProductsDTOs = (List<ImportCategoriesProductsDTO>)serializer.Deserialize(reader);
            }
            foreach (var categoryProducts in categoryProductsDTOs)
            {
                CategoryProduct cp = new()
                {
                    CategoryId = categoryProducts.CategoryId,
                    ProductId = categoryProducts.ProductId
                };
                categoryProduct.Add(cp);
            }
            context.CategoryProducts.AddRange(categoryProduct);
            context.SaveChanges();
            return $"Successfully imported {categoryProduct.Count}";
        }
        //5
        public static string GetProductsInRange(ProductShopContext context)
        {
            XmlSerializer serializer = new(typeof(List<ExportProductsDTO>), new XmlRootAttribute("Products"));
            XmlSerializerNamespaces namesSpaces = new();
            namesSpaces.Add("", "");
            StringBuilder sb = new();
            using StringWriter writer = new(sb);
            var products = context
                .Products
                .Where(x => x.Price >= 500 && x.Price <= 1000)
                .OrderBy(x => x.Price)
                .Select(x => new ExportProductsDTO
                {
                    Name = x.Name,
                    Price = x.Price,
                    Buyer = x.Buyer.FirstName + " " + x.Buyer.LastName
                })
            .Take(10)
            .ToList();
            serializer.Serialize(writer, products, namesSpaces);
            return sb.ToString().TrimEnd();
        }
        //6
        public static string GetSoldProducts(ProductShopContext context)
        {
            XmlSerializer serializer = new(typeof(List<ExportUsersDTO>), new XmlRootAttribute("Users"));
            XmlSerializerNamespaces namesSpaces = new();
            namesSpaces.Add("", "");
            StringBuilder sb = new();
            using StringWriter writer = new(sb);
            var users = context
                .Users
                .Where(x => x.ProductsSold.Any())
                .OrderBy(x => x.LastName)
                .ThenBy(x => x.FirstName)
                .Select(x => new ExportUsersDTO
                {
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    importSoldProductsDTOs = (List<ExportSoldProductsDTO>)x.ProductsSold.Select(x => new ExportSoldProductsDTO
                    {
                        Name = x.Name,
                        Price = x.Price
                    })
                })
            .Take(5)
            .ToList();
            serializer.Serialize(writer, users, namesSpaces);
            return sb.ToString().TrimEnd();
        }
        //7
        public static string GetCategoriesByProductsCount(ProductShopContext context)
        {
            XmlSerializer serializer = new(typeof(List<ExportCategoriesDTO>), new XmlRootAttribute("Categories"));
            XmlSerializerNamespaces namesSpaces = new();
            namesSpaces.Add("", "");
            StringBuilder sb = new();
            using StringWriter writer = new(sb);
            List<ExportCategoriesDTO> categories = context
                .Categories
                .Select(x => new ExportCategoriesDTO
                {
                        Name = x.Name,
                        count = x.CategoryProducts.Count(),
                        averagePrice = x.CategoryProducts.Average(x => x.Product.Price),
                        totalRevenue = x.CategoryProducts.Sum(x => x.Product.Price)
                })
                .OrderByDescending(x => x.count)
                .ThenBy(x => x.totalRevenue)
           .ToList();
            serializer.Serialize(writer, categories, namesSpaces);
            return sb.ToString().TrimEnd();
        }
        //8
        public static string GetUsersWithProducts(ProductShopContext context)
        {
            var usersWithProducts = context.Users
             .Where(user => user.ProductsSold.Any())
             .OrderByDescending(user => user.ProductsSold.Count)
             .Take(10)
             .Select(user => new
             {
                 FirstName = user.FirstName,
                 LastName = user.LastName,
                 Age = user.Age,
                 SoldProductsCount = user.ProductsSold.Count,
                 SoldProducts = user.ProductsSold
                     .Select(product => new
                     {
                         Name = product.Name,
                         Price = product.Price
                     })
                     .OrderByDescending(product => product.Price)
                     .ToList()
             })
             .ToList();

            int totalUsers = usersWithProducts.Count();

            XElement xmlUsers = new XElement("Users",
                new XElement("count", totalUsers),
                new XElement("users",
                    usersWithProducts.Select(user =>
                        new XElement("User",
                            new XElement("firstName", user.FirstName),
                            new XElement("lastName", user.LastName),
                            new XElement("age", user.Age),
                            new XElement("SoldProducts",
                                new XElement("count", user.SoldProductsCount),
                                user.SoldProducts.Select(product =>
                                    new XElement("Product",
                                        new XElement("name", product.Name),
                                        new XElement("price", product.Price)
                                    )
                                )
                            )
                        )
                    )
                )
            );

            XDocument xmlDocument = new XDocument(new XDeclaration("1.0", "utf-8", null), xmlUsers);
            return xmlDocument.ToString();
        }
        public static void Main()
        {
            ProductShopContext context = new ProductShopContext();
            //string inputXml = File.ReadAllText(@"..\..\..\Datasets\categories-products.xml");
            Console.WriteLine(GetUsersWithProducts(context));
        }
    }
}
