﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ProductShop.DTOs.Export
{
    [XmlType("User")]
    public class ExportUsersAndProductsDTO
    {
        [XmlElement]
        public string firstName { get; set; } = null!;
        [XmlElement]
        public string lastName { get; set; } = null!;
        [XmlElement]
        public int? age { get; set; }
    }
}
