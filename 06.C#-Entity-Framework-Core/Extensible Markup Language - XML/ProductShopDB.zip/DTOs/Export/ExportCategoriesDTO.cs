﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ProductShop.DTOs.Export
{
    [XmlType("Category")]
    public class ExportCategoriesDTO
    {
        [XmlElement("name")]
        public string Name { get; set; } = null!;
        [XmlElement]
        public int count { get; set; }
        [XmlElement]
        public decimal averagePrice { get; set; }
        [XmlElement]
        public decimal totalRevenue { get; set; }
    }
}
