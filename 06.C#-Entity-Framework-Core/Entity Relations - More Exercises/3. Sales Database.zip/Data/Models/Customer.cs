﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P03_SalesDatabase.Data.Models
{
    public class Customer
    {
        public Customer()
        {
            Sales = new List<Sale>();
        }
        [Key]
        public int CustomerId { get; set; }
        [MaxLength(100),Unicode,Required]
        public string Name { get; set; }
        [Required,MaxLength(80)]
        public string Email { get; set; }
        [Required]
        public string CreditCardNumber { get; set; }
        [Required]
        public ICollection<Sale> Sales { get; set; }
    }
}
