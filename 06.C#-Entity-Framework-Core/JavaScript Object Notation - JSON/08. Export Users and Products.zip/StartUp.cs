﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ProductShop
{
    public class StartUp
    {
        public static string GetUsersWithProducts(ProductShopContext context)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings
            {
                Formatting = Formatting.Indented,
                NullValueHandling = NullValueHandling.Ignore
            };
            var users = context.Users
                .Where(x=>x.ProductsSold.Count>0)
                .OrderByDescending(x=>x.ProductsSold.Count((p => p.BuyerId != null)))
                .Select(x => new
                {
                    firstName = x.FirstName,
                    lastName = x.LastName,
                    age = x.Age,
                    soldProducts = new
                    {
                        count = x.ProductsSold.Count((p => p.BuyerId != null)),
                        products = x.ProductsSold.Where(p => p.BuyerId != null).Select(x => new
                        {
                            name = x.Name,
                            price = x.Price
                        })
                    }
                }).ToList();
            var result = new
            {
              usersCount = users.Count(),
              users = users
            };
            return JsonConvert.SerializeObject(result,settings);
        }
        public static void Main()
        {
            //using (SqlConnection con = new(@"Server=DESKTOP-745T20N\SQLEXPRESS;Database=ProductShop;Integrated Security=True;TrustServerCertificate = True"))
            //    con.Open();
            ProductShopContext context = new ProductShopContext();
            //string inputJson = File.ReadAllText(@"..\..\..\Datasets\categories-products.json");
            Console.WriteLine(GetUsersWithProducts(context));
        }
    }
}