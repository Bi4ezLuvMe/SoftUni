﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ProductShop
{
    public class StartUp
    {
        public static string GetSoldProducts(ProductShopContext context)
        {
            var users = JsonConvert.SerializeObject(context.Users.Where(x => x.ProductsSold.Any(x=>x.Buyer != null)).OrderBy(x => x.LastName).ThenBy(x => x.FirstName).Select(x => new
            {
                firstName =x.FirstName,
                lastName = x.LastName,
                soldProducts = x.ProductsSold.Where(x=>x.Buyer!=null).Select(x => new
                {
                    name = x.Name,
                    price = x.Price,
                    buyerFirstName = x.Buyer.FirstName,
                    buyerLastName = x.Buyer.LastName
                })
            }), Formatting.Indented);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(users);
            return sb.ToString().TrimEnd();
        }
        public static void Main()
        {
            //using (SqlConnection con = new(@"Server=DESKTOP-745T20N\SQLEXPRESS;Database=ProductShop;Integrated Security=True;TrustServerCertificate = True"))
            //    con.Open();
            ProductShopContext context = new ProductShopContext();
            //string inputJson = File.ReadAllText(@"..\..\..\Datasets\categories-products.json");
            Console.WriteLine(GetSoldProducts(context));
        }
    }
}