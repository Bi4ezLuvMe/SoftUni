﻿using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;
using System.Collections.Generic;
using System.IO;

namespace ProductShop
{
    public class StartUp
    {
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            var categories = JsonConvert.DeserializeObject<List<Category>>(inputJson);
            var validCategories = categories.Where(x=>x.Name is not null).ToList();
            context.Categories.AddRange(validCategories);
            context.SaveChanges();
            return $"Successfully imported {validCategories.Count}";
        }
        public static void Main()
        {
            //using (SqlConnection con = new(@"Server=DESKTOP-745T20N\SQLEXPRESS;Database=ProductShop;Integrated Security=True;TrustServerCertificate = True"))
            //    con.Open();
            ProductShopContext context = new ProductShopContext();
            string inputJson = File.ReadAllText(@"..\..\..\Datasets\categories.json");
            Console.WriteLine(ImportCategories(context, inputJson));
        }
    }
}