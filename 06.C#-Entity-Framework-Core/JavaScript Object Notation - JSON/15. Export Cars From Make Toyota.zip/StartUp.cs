﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string GetCarsFromMakeToyota(CarDealerContext context)
        {
            var cars = JsonConvert.SerializeObject(context.Cars.Where(x=>x.Make == "Toyota").OrderBy(x => x.Model).ThenByDescending(x => x.TraveledDistance).Select(x => new
            {
                Id = x.Id,
                Make =x.Make,
                Model = x.Model,
                TraveledDistance = x.TraveledDistance
            }),Formatting.Indented);
           
            return cars;
        }
        public static void Main()
        {
            CarDealerContext context = new();
            //string inputJson = File.ReadAllText(@"../../../Datasets/sales.json");
            Console.WriteLine(GetCarsFromMakeToyota(context));
        }
    }
}