﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson);
            var validParts = parts.Where(p => context.Suppliers.Any(x=>x.Id == p.SupplierId));
            context.Parts.AddRange(validParts);
            context.SaveChanges();
            return $"Successfully imported {validParts.Count()}.";
        }
        public static void Main()
        {
            CarDealerContext context = new();
            string inputJson = File.ReadAllText(@"../../../Datasets/parts.json");
            Console.WriteLine(ImportParts(context, inputJson));
        }
    }
}