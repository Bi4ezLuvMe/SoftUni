﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string GetCarsWithTheirListOfParts(CarDealerContext context)
        {
            var carsWithParts = JsonConvert.SerializeObject(context.Cars.Select(x => new
            {
                car = new
                {
                    Make = x.Make,
                    Model = x.Model,
                    TraveledDistance = x.TraveledDistance
                },
                parts = x.PartsCars.Select(x => new
                {
                    Name = x.Part.Name,
                    Price = $"{x.Part.Price:f2}",
                })
            }), Formatting.Indented);

            return carsWithParts;
        }
        public static void Main()
        {
            CarDealerContext context = new();
            //string inputJson = File.ReadAllText(@"../../../Datasets/cars.json");
            Console.WriteLine(GetCarsWithTheirListOfParts(context));
        }
    }
}