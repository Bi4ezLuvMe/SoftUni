﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ProductShop
{
    public class StartUp
    {
        public static string GetCategoriesByProductsCount(ProductShopContext context)
        {
            var categories = JsonConvert.SerializeObject(context.Categories.OrderByDescending(x => x.CategoriesProducts.Count).Select(x => new
            {
                category = x.Name,
                productsCount = x.CategoriesProducts.Count,
                averagePrice = $"{x.CategoriesProducts.Average(x => x.Product.Price):f2}",
                totalRevenue = $"{x.CategoriesProducts.Sum(x => x.Product.Price):f2}"
            }),Formatting.Indented);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(categories);
            return sb.ToString().TrimEnd();
        }
        public static void Main()
        {
            //using (SqlConnection con = new(@"Server=DESKTOP-745T20N\SQLEXPRESS;Database=ProductShop;Integrated Security=True;TrustServerCertificate = True"))
            //    con.Open();
            ProductShopContext context = new ProductShopContext();
            //string inputJson = File.ReadAllText(@"..\..\..\Datasets\categories-products.json");
            Console.WriteLine(GetCategoriesByProductsCount(context));
        }
    }
}