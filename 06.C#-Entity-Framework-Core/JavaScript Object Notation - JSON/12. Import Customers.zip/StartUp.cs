﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customers = JsonConvert.DeserializeObject<List<Customer>>(inputJson);
            context.Customers.AddRange(customers);
            context.SaveChanges();
            return $"Successfully imported {customers.Count()}.";
        }
        public static void Main()
        {
            CarDealerContext context = new();
            string inputJson = File.ReadAllText(@"../../../Datasets/customers.json");
            Console.WriteLine(ImportCustomers(context, inputJson));
        }
    }
}