﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string GetLocalSuppliers(CarDealerContext context)
        {
            var suppliers = JsonConvert.SerializeObject(context.Suppliers.Where(x => x.IsImporter == false).Select(x => new
            {
                Id = x.Id,
                Name = x.Name,
                PartsCount = x.Parts.Count
            }),Formatting.Indented);
           
            return suppliers;
        }
        public static void Main()
        {
            CarDealerContext context = new();
            //string inputJson = File.ReadAllText(@"../../../Datasets/sales.json");
            Console.WriteLine(GetLocalSuppliers(context));
        }
    }
}