﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            var sales = JsonConvert.DeserializeObject<List<Sale>>(inputJson);
            context.Sales.AddRange(sales);
            context.SaveChanges();
            return $"Successfully imported {sales.Count()}.";
        }
        public static void Main()
        {
            CarDealerContext context = new();
            string inputJson = File.ReadAllText(@"../../../Datasets/sales.json");
            Console.WriteLine(ImportSales(context, inputJson));
        }
    }
}