﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string GetOrderedCustomers(CarDealerContext context)
        {
            var customers = JsonConvert.SerializeObject(context.Customers.OrderBy(x => x.BirthDate).ThenBy(x => x.IsYoungDriver).Select(x => new
            {
                Name = x.Name,
                BirthDate = x.BirthDate.ToString("dd/MM/yyyy"),
                IsYoungDriver = x.IsYoungDriver
            }),Formatting.Indented);
           
            return customers;
        }
        public static void Main()
        {
            CarDealerContext context = new();
            //string inputJson = File.ReadAllText(@"../../../Datasets/sales.json");
            Console.WriteLine(GetOrderedCustomers(context));
        }
    }
}