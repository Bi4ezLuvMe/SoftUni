﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var cars = JsonConvert.DeserializeObject<ImportCarDto[]>(inputJson);

            foreach (var carDto in cars)
            {
                Car car = new Car
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TraveledDistance = carDto.TravelledDistance
                };

                context.Cars.Add(car);
                context.SaveChanges();
                foreach (var partId in carDto.PartsId)
                {
                    PartCar partCar = new PartCar
                    {
                        CarId = car.Id,
                        PartId = partId
                    };

                    if (car.PartsCars.FirstOrDefault(p => p.PartId == partId) == null)
                    {
                        context.PartsCars.Add(partCar);
                    }
                }
            }

            context.SaveChanges();

            return $"Successfully imported {cars.Length}.";
        }
        public static void Main()
        {
            CarDealerContext context = new();
            string inputJson = File.ReadAllText(@"../../../Datasets/cars.json");
            Console.WriteLine(ImportCars(context, inputJson));
        }
    }
}