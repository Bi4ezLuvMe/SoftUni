﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ProductShop
{
    public class StartUp
    {
        public static string GetProductsInRange(ProductShopContext context)
        {
            var products = JsonConvert.SerializeObject(context.Products.Where(x => x.Price >= 500 && x.Price <= 1000).OrderBy(x => x.Price).Select(x => new
            {
                name = x.Name,
                price = x.Price,
                seller = x.Seller.FirstName+" "+x.Seller.LastName
            }),Formatting.Indented);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(products);
            return sb.ToString().TrimEnd();
        }
        public static void Main()
        {
            //using (SqlConnection con = new(@"Server=DESKTOP-745T20N\SQLEXPRESS;Database=ProductShop;Integrated Security=True;TrustServerCertificate = True"))
            //    con.Open();
            ProductShopContext context = new ProductShopContext();
            //string inputJson = File.ReadAllText(@"..\..\..\Datasets\categories-products.json");
            Console.WriteLine(GetProductsInRange(context));
        }
    }
}