﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-745T20N\SQLEXPRESS;Database=Footballers;Integrated Security=True;TrustServerCertificate = True";
    }
}
