﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data.Models
{
    public class Course
    {

        public Course()
        {
            Students = new List<Student>();
            Resources = new List<Resource>();
            Homeworks = new List<Homework>();
            StudentsEnrolled = new HashSet<StudentCourse>();
        }
        [Key]
        public int CourseId { get; set; }
        [Required]
        public string Name { get; set; }

        public string? Description { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        [ForeignKey("StudentId")]
        public List<Student> Students { get; set; }
        [Required]
        [ForeignKey("ResourceId")]
        public List<Resource> Resources { get; set; }
        [Required]
        [ForeignKey("HomeworkId")]
        public List<Homework> Homeworks { get; set; }
        public virtual ICollection<StudentCourse> StudentsEnrolled { get; set; }
    }
}
