﻿using Microsoft.EntityFrameworkCore;
using P01_StudentSystem.Data.Models;
using System.ComponentModel.DataAnnotations;

namespace P01_StudentSystem.Data
{
    public class StudentSystemContext : DbContext
    {
        public StudentSystemContext()
        {
        }
        public StudentSystemContext(DbContextOptions<StudentSystemContext> options) : base(options)
        {
        }
        [Required]
        public DbSet<Student> Students { get; set; }
        [Required]
        public DbSet<Course> Courses { get; set; }
        [Required]
        public DbSet<Resource> Resources { get; set; }
        [Required]
        public DbSet<Homework> Homeworks { get; set; }
        [Required]
        public DbSet<StudentCourse> StudentsCourses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=DESKTOP-745T20N\\SQLEXPRESS;Database=SoftUni;Integrated Security=True;TrustServerCertificate = True");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<StudentCourse>(sc =>
            {
                sc.HasKey("StudentId", "CourseId");
            });
            modelBuilder.Entity<Student>(entity =>
            {
                entity.Property(x => x.Name).HasMaxLength(100).IsUnicode(true);
                entity.Property(x=>x.PhoneNumber).HasMaxLength(10).IsUnicode(false);
            });
            modelBuilder.Entity<Course>(entity =>
            {
                entity.Property(x => x.Name).HasMaxLength(80).IsUnicode(true);
                entity.Property(x => x.Description).IsUnicode(true);
            });
            modelBuilder.Entity<Resource>(entity =>
            {
                entity.Property(x => x.Name).HasMaxLength(50).IsUnicode(true);
                entity.Property(x => x.Url).IsUnicode(false);
            });
            modelBuilder.Entity<Homework>(entity =>
            {
                entity.Property(x => x.Content).IsUnicode(false);
            });

            base.OnModelCreating(modelBuilder);
        }

    }
}
