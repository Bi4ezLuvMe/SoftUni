﻿namespace LineNumbers
{
    using System;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            string outputFilePath = @"..\..\..\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            using (StreamReader reader = new(inputFilePath))
            {
                using(StreamWriter writer = new(outputFilePath))
                {
                    int count = 1;
                    while (!reader.EndOfStream)
                    {
                        int specialSym = 0;
                        string line = reader.ReadLine();
                        string[]strings = line.Split(' ');
                        int sum = 0;
                        char[]letters = line.ToCharArray();
                        for (int i = 0; i < letters.Length; i++)
                        {
                            if (!Char.IsLetterOrDigit(letters[i]) && letters[i]!=' ')
                            {
                                specialSym++;
                            }
                        }
                        for (int i = 0; i < strings.Length; i++)
                        {
                            sum += strings[i].Length;
                        }
                        writer.WriteLine($"Line {count++}: {line} ({sum-specialSym}) ({specialSym})");
                    }
                }
            }
        }
    }
}
