﻿namespace EvenLines
{
    using System;
    using System.IO;
    using System.Linq;

    public class EvenLines
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";

           ProcessLines(inputFilePath);
        }

        public static string ProcessLines(string inputFilePath)
        {
            using (StreamReader reader = new(inputFilePath))
            {
                int count = 0;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (count % 2 == 0)
                    {
                        string[]temp = line.Split(' ');
                        Array.Reverse(temp);
                        string temp1 = string.Empty;
                        for (int i = 0; i < temp.Length; i++)
                        {
                            temp1 += temp[i]+ " ";
                        }
                         var line1 = temp1.Replace('-', '@')
                        .Replace(',', '@')
                        .Replace('.', '@')
                       .Replace('!', '@')
                        .Replace('?', '@');
                          Console.WriteLine(line1);
                    }
                    count++;
                }
                return string.Empty;
            }
        }
    }
}

