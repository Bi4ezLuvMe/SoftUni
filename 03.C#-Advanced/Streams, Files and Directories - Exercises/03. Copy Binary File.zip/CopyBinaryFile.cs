﻿namespace CopyBinaryFile
{
    using System;
    using System.IO;

    public class CopyBinaryFile
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\copyMe.png";
            string outputFilePath = @"..\..\..\copyMe-copy.png";

            CopyFile(inputFilePath, outputFilePath);
        }

        public static void CopyFile(string inputFilePath, string outputFilePath)
        {
           using(FileStream stream = new(inputFilePath, FileMode.Open)) 
            {
                using (StreamWriter writer = new StreamWriter(outputFilePath))
                {
                    while (stream.CanSeek)
                    {
                       int next = stream.ReadByte();
                        if(next == -1)
                        {
                            break;
                        }
                        writer.WriteLine(next);
                      
                    }
                }
            }
        }
    }
}
