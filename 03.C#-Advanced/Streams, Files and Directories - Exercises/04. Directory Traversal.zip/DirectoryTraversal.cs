﻿namespace DirectoryTraversal
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class DirectoryTraversal
    {
        static void Main()
        {
            string path = Console.ReadLine();
            string reportFileName = @"\report.txt";

            string reportContent = TraverseDirectory(path);
            Console.WriteLine(reportContent);

            WriteReportToDesktop(reportContent, reportFileName);
        }

        public static string TraverseDirectory(string inputFolderPath)
        {
            SortedDictionary<string, List<FileInfo>> files = new();
            string[]files1 = Directory.GetFiles(inputFolderPath);
            foreach (string file in files1)
            {
                FileInfo fileInfo = new FileInfo(file);
                if(files.ContainsKey(fileInfo.Extension))
                {
                    files[fileInfo.Extension].Add(fileInfo);
                }
                else
                {
                    files.Add(fileInfo.Extension, new List<FileInfo> { fileInfo });
                }
            }
            StringBuilder sb = new();
            foreach (var item in files.OrderByDescending(x=>x.Value.Count))
            {
                sb.AppendLine(item.Key);
                foreach (var file in item.Value.OrderBy(x=>x.Length))
                {
                    sb.AppendLine($"---{file} - {file.Length/1024.0:f3}kb");
                }
            }
            return sb.ToString();
        }

        public static void WriteReportToDesktop(string textContent, string reportFileName)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)+reportFileName;
            File.WriteAllText(path, textContent);
        }
    }
}
