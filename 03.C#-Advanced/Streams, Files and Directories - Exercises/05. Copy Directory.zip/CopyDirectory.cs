﻿namespace CopyDirectory
{
    using System;
    using System.IO;

    public class CopyDirectory
    {
        static void Main()
        {
            string inputPath =  @$"{Console.ReadLine()}";
            string outputPath = @$"{Console.ReadLine()}";

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            FileInfo file = new FileInfo(inputPath);
           using(StreamReader reader = new(inputPath))
            {
                using(StreamWriter writer = new(outputPath))
                {
                    reader.ReadToEnd();
                }
            }
        }
    }
}
