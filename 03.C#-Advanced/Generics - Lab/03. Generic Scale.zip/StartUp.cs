﻿namespace GenericScale
{
    public class EqualityScale<T>
    {
        T left { get; set; }
        T right { get; set; }
        public EqualityScale(T left, T right)
        {
            this.left = left;
            this.right = right;
        }
        public bool AreEqual()
        {
            return left.Equals(right);
        }
    }
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}
