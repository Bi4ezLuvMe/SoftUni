﻿using DefiningClasses;
using System.Data.SqlTypes;

namespace DefiningClasses
{
    public class Car
    {
        string model;
        public string Model { get { return model; } set {  model = value; } }
        double fuelAmount;
        public double FuelAmount { get {  return fuelAmount; } set { fuelAmount = value; } }
        double fuelConsumptionPerKilometer;
        public double FuelConsumptionPerKilometer { get {  return fuelConsumptionPerKilometer;} set{fuelConsumptionPerKilometer = value;} }
        double travelledDistance;
        public double TravelledDistance { get {  return travelledDistance; } set {  travelledDistance = value; } }
        public Car(string model, double fuelAmount, double fuelConsumptionPerKilometer)
        {
            Model = model;  
            FuelAmount = fuelAmount;
            FuelConsumptionPerKilometer = fuelConsumptionPerKilometer;
        }
        public void Drive(double distance,Car car)
        {
            if (car.fuelAmount >= distance * car.FuelConsumptionPerKilometer)
            {
                car.TravelledDistance += distance;
                car.FuelAmount -= distance * car.FuelConsumptionPerKilometer;
            }
            else
            {
                Console.WriteLine("Insufficient fuel for the drive");
            }
        }
    }
}
public class StartUp
{
    static void Main(string[] args)
    {
        int n = int.Parse(Console.ReadLine());
        List<Car> cars = new List<Car>();
        for (int i = 0; i < n; i++)
        {
            string[] command = Console.ReadLine().Split();
            string model = command[0];
            double fuelAmount = double.Parse(command[1]);
            double fuelConsumpPerKm = double.Parse(command[2]);
            Car car = new Car(model,fuelAmount,fuelConsumpPerKm);
            cars.Add(car);
        }
        string command1 = Console.ReadLine();
        while (command1 != "End")
        {
            string[] tokens = command1.Split();
            string model = tokens[1];
            double distance = double.Parse(tokens[2]);
            foreach (var item in cars)
            {
                if (item.Model == model)
                {
                    item.Drive(distance, item);
                }
            }
            command1= Console.ReadLine();
            
        }
        foreach(var item in cars)
        {
            Console.WriteLine($"{item.Model} {item.FuelAmount:f2} {item.TravelledDistance}");
        }
    }
}