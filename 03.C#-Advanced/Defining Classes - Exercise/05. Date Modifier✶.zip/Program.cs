﻿using DefiningClasses;
using System.Data.SqlTypes;

namespace DefiningClasses
{
    public class DateModifier
    {
        public string firstDate;
        public string secondDate;
        public double Days(string firstDate,string secondDate)
        {
            int[]first1 = firstDate.Split().Select(int.Parse).ToArray();
            int[] second1 = secondDate.Split().Select(int.Parse).ToArray();
            DateTime first = new DateTime(first1[0], first1[1], first1[2]);
            DateTime second = new DateTime(second1[0], second1[1], second1[2]);
            double days = (second.Subtract(first).TotalDays);
            return days;
        }
    }
   

}
public class StartUp
{
    static void Main(string[] args)
    {
        DateModifier df = new();
        df.firstDate = Console.ReadLine();
        df.secondDate = Console.ReadLine();
        Console.WriteLine(Math.Abs(df.Days(df.firstDate, df.secondDate)));
    }
}
