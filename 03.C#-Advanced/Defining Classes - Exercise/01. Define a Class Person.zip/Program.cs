﻿namespace DefiningClasses
{
    class Person
    {
        string name;
        public string Name { get { return name; } set { name = value; } }
        int age;
        public int Age { get { return age; } set { age = value; } }

    }
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Test";
            person.Age = 69;
        }
    }
}