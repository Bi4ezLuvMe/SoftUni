﻿namespace DefiningClasses
{
    public class Car
    {
        string model;
        public string Model { get { return model; } set { model = value; } }
        public class Engine
        {
            string model;
            public string Model { get { return model; } set { model = value; } }
            int power;
            public int Power { get { return power; } set { power = value; } }
            int displacement;
            public int Displacement { get { return displacement; } set { displacement = value; } }//optional
            string efficiency;
            public string Efficiency//optional
            {
                get { return efficiency; }
                set
                {
                    efficiency = value;
                }
            }
            public Engine(string model, int power)
            {
                Model = model;
                Power = power;
                Displacement = 0;
                efficiency = "n/a";
            }
            public Engine(string model, int power, int displacement) : this(model, power)
            {
                Displacement = displacement;
            }
            public Engine(string model, int power, string efficiency) : this(model, power)
            {
                Efficiency = efficiency;
            }
            public Engine(string model, int power, int displacement, string efficiency) : this(model, power)
            {
                Displacement = displacement;
                Efficiency = efficiency;
            }
        }
        int weight;
        public int Weight { get { return weight; } set { weight = value; } }//optional
        string color;
        public string Color { get { return color; } set { color = value; } }//optional
        public Car(string model, Engine engine)
        {
            Model = model;
            Engine Engine = engine;
            Weight = 0;
            Color = "n/a";
        }
        public Car(string model, Engine engine, int weight) : this(model, engine)
        {
            Weight = weight;
        }
        public Car(string model, Engine engine, string color) : this(model, engine)
        {
            Color = color;
        }
        public Car(string model, Engine engine, int weight, string color) : this(model, engine)
        {
            Weight = weight;
            Color = color;
        }
    }


    public class StartUp
    {
        static void Main(string[] args)
        {
            int nEngine = int.Parse(Console.ReadLine());
            List<Car.Engine> engines = new();
            for (int i = 0; i < nEngine; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string engineModel = tokens[0];
                int power = int.Parse(tokens[1]);
                if (tokens.Length == 2)
                {
                    Car.Engine engine = new Car.Engine(engineModel, power);
                    engines.Add(engine);
                }
                else if (tokens.Length == 3)
                {
                    if (int.TryParse(tokens[2], out int displacement))
                    {
                        Car.Engine engine = new Car.Engine(engineModel, power, displacement);
                        engines.Add(engine);
                    }
                    else
                    {
                        string efficiency = tokens[2];
                        Car.Engine engine = new Car.Engine(engineModel, power, efficiency);
                        engines.Add(engine);
                    }
                }
                else if (tokens.Length == 4)
                {
                    int displament = int.Parse(tokens[2]);
                    string efficiency = tokens[3];
                    Car.Engine engine = new Car.Engine(engineModel, power, displament, efficiency);
                    engines.Add(engine);
                }
            }
            int M = int.Parse(Console.ReadLine());
            Dictionary<Car, string> cars = new();
            for (int i = 0; i < M; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string model = tokens[0];
                string engine = tokens[1];
                if (tokens.Length == 2)
                {
                    foreach (var item in engines)
                    {
                        if (item.Model == engine)
                        {
                            Car car = new Car(model, item);
                            cars.Add(car, engine);
                        }
                    }

                }
                else if (tokens.Length == 3)
                {
                    if (int.TryParse(tokens[2], out int weight))
                    {
                        foreach (var item in engines)
                        {
                            if (item.Model == engine)
                            {
                                Car car = new Car(model, item, weight);
                                cars.Add(car, engine);
                            }
                        }
                    }
                    else
                    {
                        string color = tokens[2];
                        foreach (var item in engines)
                        {
                            if (item.Model == engine)
                            {
                                Car car = new Car(model, item, color);
                                cars.Add(car, engine);
                            }
                        }
                    }
                }
                else if (tokens.Length == 4)
                {
                    int weight = int.Parse(tokens[2]);
                    string color = tokens[3];
                    foreach (var item in engines)
                    {
                        if (item.Model == engine)
                        {
                            Car car = new Car(model, item, weight, color);
                            cars.Add(car, engine);
                        }
                    }
                }
            }
            foreach (var car in cars)
            {
                Console.WriteLine($"{car.Key.Model}:");
                Console.WriteLine($" {car.Value}:");
                foreach (var engine in engines)
                {
                    if (engine.Model == car.Value)
                    {
                        Console.WriteLine($"  Power: {engine.Power}");
                        if (engine.Displacement == 0)
                        {
                            Console.WriteLine($"  Displacement: n/a");
                        }
                        else
                        {
                            Console.WriteLine($"  Displacement: {engine.Displacement}");
                        }
                        Console.WriteLine($"  Efficiency: {engine.Efficiency}");
                    }
                }
                if (car.Key.Weight == 0)
                {
                    Console.WriteLine($" Weight: n/a");
                }
                else
                {
                    Console.WriteLine($" Weight: {car.Key.Weight}");
                }
                Console.WriteLine($" Color: {car.Key.Color}");
            }
        }
    }
}
