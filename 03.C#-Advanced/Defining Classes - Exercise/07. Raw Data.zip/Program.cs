﻿namespace DefiningClasses
{
    public class Car
    {
        string model;
        public string Model { get { return model; } set { model = value; } }
        public class Engine
        {
            double speed;
            public double Speed { get { return speed; } set { speed = value; } }
            double power;
            public double Power { get { return power; } set { power = value; } }
            public Engine(double speed, double power)
            {
                Speed = speed;
                Power = power;
            }
        }
        public class Cargo
        {
            string type;
            public string Type { get { return type; } set { type = value; } }
            double weight;
            public double Weight
            {
                get { return weight; }
                set { weight = value; }
            }
            public Cargo(string type, double weight)
            {
                Type = type;
                Weight = weight;
            }
        }
        public class Tire
        {
            int age;
            public int Age { get { return age; } set { age = value; } }
            double pressure;
            public double Pressure { get { return pressure; } set { pressure = value; } }
            public Tire(int age,double pressure)
            {
                Age = age;
                Pressure = pressure;
            }
        }

        public Car(string model, Engine engine, Cargo cargo, Tire[] tires)
        {
            Model = model;
            Engine Engine = engine;
            Cargo Cargo = cargo;
            Tire[] Tires = tires;
        }
    }


    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Dictionary<Car, string> cars = new();
            for (int i = 0; i < n; i++)
            {
                string[] tokens = Console.ReadLine().Split();
                string model = tokens[0];
                double engineSpeed = double.Parse(tokens[1]);
                double enginePower = double.Parse(tokens[2]);
                double cargoWeight = double.Parse(tokens[3]);
                string cargoType = tokens[4];
                double tire1Pressure = double.Parse(tokens[5]);
                int tire1Age = int.Parse(tokens[6]);
                double tire2Pressure = double.Parse(tokens[7]);
                int tire2Age = int.Parse(tokens[8]);
                double tire3Pressure = double.Parse(tokens[9]);
                int tire3Age = int.Parse(tokens[10]);
                double tire4Pressure = double.Parse(tokens[11]);
                int tire4Age = int.Parse(tokens[12]);
                if(cargoType == "fragile")
                {
                    if (tire1Pressure < 1 || tire2Pressure < 1 || tire3Pressure < 1 || tire4Pressure < 1)
                    {
                        Car.Engine engine = new Car.Engine(engineSpeed, enginePower);
                        Car.Cargo cargo = new Car.Cargo(cargoType, cargoWeight);
                        Car.Tire[] tires = new Car.Tire[4]
                        {
                        new Car.Tire(tire1Age,tire1Pressure),
                        new Car.Tire(tire2Age,tire2Pressure),
                        new Car.Tire(tire3Age,tire3Pressure),
                        new Car.Tire(tire4Age,tire4Pressure),
                        };
                        Car car = new Car(model, engine, cargo, tires);
                        cars.Add(car,cargoType);
                    }
                }else if(cargoType == "flammable")
                {
                    if (enginePower > 250)
                    {
                            Car.Engine engine = new Car.Engine(engineSpeed, enginePower);
                            Car.Cargo cargo = new Car.Cargo(cargoType, cargoWeight);
                            Car.Tire[] tires = new Car.Tire[4]
                            {
                            new Car.Tire(tire1Age,tire1Pressure),
                            new Car.Tire(tire2Age,tire2Pressure),
                            new Car.Tire(tire3Age,tire3Pressure),
                            new Car.Tire(tire4Age,tire4Pressure),
                            };
                            Car car = new Car(model, engine, cargo, tires);
                            cars.Add(car,cargoType);
                    }
                }
            }
            string wantedType = Console.ReadLine();
            foreach (var item in cars)
            {
               
                if (item.Value== wantedType)
                {
                    Console.WriteLine(item.Key.Model);
                }
            }
        }
    }
}