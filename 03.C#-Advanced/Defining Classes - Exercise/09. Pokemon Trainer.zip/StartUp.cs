﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SoftUniParking
{
    public class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int HorsePower { get; set; }
        public string RegistrationNumber { get; set; }
        public Car(string make, string model, int horsePower, string registrationNumber)
        {
            Make = make;
            Model = model;
            HorsePower = horsePower;
            RegistrationNumber = registrationNumber;
        }
        public override string ToString()
        {
            string result = $"Make: {this.Make}{Environment.NewLine}";
            result += $"Model: {this.Model}{Environment.NewLine}";
            result += $"HorsePower: {this.HorsePower}{Environment.NewLine}";
            result += $"RegistrationNumber: {this.RegistrationNumber}";

            return result;
        }
    }
    public class Parking
    {
        public Parking(int capacity)
        {
            Cars = new();
            this.capacity = capacity;
        }
         private Dictionary<string, Car> Cars;
        private int capacity;
        public int Count
        {
            get { return Cars.Count; }
        }
        public string AddCar(Car car)
        {
            if (Cars.ContainsKey(car.RegistrationNumber))
            {
                return ("Car with that registration number, already exists!");
            }
            if (this.Count >= this.capacity)
            {
                return ("Parking is full!");
            }
            Cars.Add(car.RegistrationNumber, car);
            return ($"Successfully added new car {car.Make} {car.RegistrationNumber}");


        }
        public string RemoveCar(string RegistrationNumber)
        {
            if (Cars.ContainsKey(RegistrationNumber))
            {
                Cars.Remove(RegistrationNumber);
                return ($"Successfully removed {RegistrationNumber}");
            }
            else
            {
                return ("Car with that registration number, doesn't exist!");
            }
        }
        public Car GetCar(string RegistrationNumber)
        {
            return Cars.Values.FirstOrDefault(x=>x.RegistrationNumber==RegistrationNumber);
        }
        public void RemoveSetOfRegistrationNumber(List<string> RegistarationNumbers)
        {
            foreach (var item in RegistarationNumbers)
            {
                RemoveCar(item);
            }
        }
    }

    public class StartUp
    {
        public static void Main(string[] args)
        {
            var car = new Car("Skoda", "Fabia", 65, "CC1856BG");
            var car2 = new Car("Audi", "A3", 110, "EB8787MN");
            Console.WriteLine(car.ToString());
            // Make: Skoda
            // Model: Fabia
            // HorsePower: 65
            // RegistrationNumber: CC1856BG
            var parking = new Parking(5);
            Console.WriteLine(parking.AddCar(car));
            //Successfully added new car Skoda CC1856BG
            Console.WriteLine(parking.AddCar(car));
            // Car with that registration number, already exists!
            Console.WriteLine(parking.AddCar(car2));
            // Successfully added new car Audi EB8787MN
            Console.WriteLine(parking.GetCar("EB8787MN").ToString());
            // Make: Audi
            // Model: A3
            // HorsePower: 110
            // RegistrationNumber: EB8787MN

            Console.WriteLine(parking.RemoveCar("EB8787MN"));
            // Successfullyremoved EB8787MN
            Console.WriteLine(parking.Count);
            // 1
        }
    }
}
