﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Trainer
    {
        string name;
        public string Name { get { return name; }set { name = value; } }
        int numberOfBadjes;
        public int Badjes { get {  return numberOfBadjes; } set {  numberOfBadjes = value; } }
        public class Pokemon
        {
            string name;
            public string Name { get { return name; } set { name = value; } }
            string element;
            public string Element { get { return element; } set { element = value; } }
            int health;
            public int Health { get { return health; }set { health = value; } }
            public Pokemon(string name,string element,int health)
            {
                Name = name; Element = element; Health = health;
            }
        }
        public List<Pokemon> pokemons;
        public Trainer(string name, List<Pokemon> pokemons)
        {
            Name = name;
            this.pokemons = pokemons;
        }
    }
    public class StartUp
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<Trainer> trainers = new();
            while(command!= "Tournament")
            {
                string[] tokens = command.Split();
                string nameTrainer = tokens[0];
                string namePokemon = tokens[1];
                string pokemonElement = tokens[2];
                int pokemonHelth = int.Parse(tokens[3]);
                Trainer.Pokemon pokemon = new(namePokemon, pokemonElement, pokemonHelth);
                Trainer trainer = new(nameTrainer,new List<Trainer.Pokemon> {pokemon });
                bool temp = false;
                foreach (var item in trainers)
                {
                    if (item.Name == nameTrainer)
                    {
                        item.pokemons.Add(pokemon);
                        temp = true;
                    }
                }
                if (temp == false) trainers.Add(trainer);
                command = Console.ReadLine();
            }
            command = Console.ReadLine();
            while (command != "End")
            {
                foreach (var item in trainers)
                {
                    //bool temp = false;
                    //foreach (var item2 in item.Key.pokemons)
                    //{
                    //    if (item2.Element == command)
                    //    {
                    //        item.Key.Badjes++;
                    //        temp = true;
                    //    }
                    //    else if(item2.Element != command&&temp==false) 
                    //    {
                    //        foreach (var item1 in item.Key.pokemons)
                    //        {
                    //            item1.Health -= 10;
                    //        }
                    //        item.Key.pokemons = item.Key.pokemons.Where(x => x.Health > 0).ToList();
                    //    }
                    //}
                    if (item.pokemons.Any(x => x.Element == command))
                    {
                        item.Badjes++;
                    }
                    else
                    {
                        foreach (var item1 in item.pokemons)
                        {
                            item1.Health -= 10;
                        }
                        item.pokemons = item.pokemons.Where(x => x.Health > 0).ToList();
                    }
                }
                command = Console.ReadLine();
            }
            trainers = trainers.OrderByDescending(x => x.Badjes).ToList();
            foreach (var item in trainers)
            {
                Console.WriteLine($"{item.Name} {item.Badjes} {item.pokemons.Count}");
            }
        }
    }
}
