﻿namespace DefiningClasses
{
    public class Person
    {
        string name;
        public string Name { get { return name; } set { name = value; } }
        int age;
        public int Age { get { return age; } set { age = value; } }
        public Person() 
        {
            Name = "No name";
            Age = 1;
        }
        public Person(int age):this()
        {
            Age = age;
        }
        public Person(string name,int age):this(age)
        {
            Name = name;
        }


    }
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            Person person2 = new Person(2);
            Person person3 = new Person("Kure",3);
        }
    }
}