﻿namespace CarManufacturer
{
    public class Car
    {
        string make;
        public string Make { get { return make; } set { make = value; } }
        string model;
        public string Model { get { return model; } set { model = value; } }
        int year;
        public int Year { get { return year; } set { year = value; } }
    }
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new();
            car.Make = Console.ReadLine();
            car.Model = Console.ReadLine();
            car.Year = int.Parse(Console.ReadLine());
            Console.WriteLine($"Make: {car.Make}");
            Console.WriteLine($"Model: {car.Model}");
            Console.WriteLine($"Year: {car.Year}");
        }
    }
}