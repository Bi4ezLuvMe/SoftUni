﻿using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CarManufacturer
{
    public class Car
    {
        string make;
        public string Make { get { return make; } set { make = value; } }
        string model;
        public string Model { get { return model; } set { model = value; } }
        int year;
        public int Year { get { return year; } set { year = value; } }
        double fuelQuantity;
        public double FuelQuantity { get {  return fuelQuantity; } set {  fuelQuantity = value; } }
        double fuelConsumption;
        public double FuelConsumption { get {  return fuelConsumption; } set { fuelConsumption = value; } }
        public void Drive(double distance)
        {
            if ((fuelQuantity - distance) * fuelConsumption > 0)
            {
                fuelQuantity -= distance * fuelConsumption;
            }
            else
            {
                Console.WriteLine("Not enough fuel to perform this trip!");
            }
        }
        public string WhoAmI()
        {
            StringBuilder sb = new();
            sb.AppendLine($"Make: {this.Make}");
            sb.AppendLine($"Model: {this.Model}");
            sb.AppendLine($"Year: {this.Year}");
            sb.AppendLine($"Fuel: {this.FuelQuantity:F2}");
            return sb.ToString();
        }
    }
    
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new();
            car.Make = Console.ReadLine();
            car.Model = Console.ReadLine();
            car.Year = int.Parse(Console.ReadLine());
            car.FuelQuantity = int.Parse(Console.ReadLine());
            car.FuelConsumption= int.Parse(Console.ReadLine());
            car.Drive(2000);
            Console.WriteLine(car.WhoAmI());
        }
    }
}