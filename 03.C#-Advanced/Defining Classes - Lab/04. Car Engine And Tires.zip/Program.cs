﻿using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CarManufacturer
{
    public class Car
    {
        string make;
        public string Make { get { return make; } set { make = value; } }
        string model;
        public string Model { get { return model; } set { model = value; } }
        int year;
        public int Year { get { return year; } set { year = value; } }
        double fuelConsumption;
        public double FuelConsumption { get { return fuelConsumption; } set { fuelConsumption = value; } }
        double fuelQuantity;
        public double FuelQuantity { get { return fuelQuantity; } set { fuelQuantity = value; } }
        Engine engine;
        public Engine Engine { get { return engine; } set { engine = value; } }
        Tire[] tires;
        public Tire[] Tires { get { return tires; } set {  tires = value; } }
        public Car()
        {
            Make = "VW";
            Model = "Golf";
            Year = 2025;
            FuelQuantity = 200;
            FuelConsumption = 10;
        }
        public Car(string make, string model, int year) : this()
        {
            this.Make = make;
            this.Model = model;
            this.Year = year;
        }
        public Car(string make, string model, int year, double fuelConsumption, double fuelQuantity) : this(make, model, year)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
        }
        public Car(string make, string model, int year, double fuelConsumption, double fuelQuantity, Engine engine, Tire[] tires) : this(make, model, year, fuelConsumption, fuelQuantity)
        {
            Engine = engine;
            Tires = tires;
        }
    }
    public class Engine
    {
        int horsePower;
        public int HorsePower { get { return horsePower; } set { horsePower = value; } }
        double cubicCapacity;
        public double CubicCapacity { get { return cubicCapacity; } set { cubicCapacity = value; } }
        public Engine(int horsePower, double cubicCapacity)
        {
            HorsePower = horsePower;
            CubicCapacity = cubicCapacity;
        }

    }
    public class Tire
    {
        int year;
        public int Year { get { return year; } set { year = value; } }
        double pressure;
        public double Pressure { get { return pressure; } set { pressure = value; } }
        public Tire(int year, double pressure)
        {
            Year = year;
            Pressure = pressure;
        }
    }

    public class StartUp
    {
        static void Main(string[] args)
        {
            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelConsumption = double.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            var tires = new Tire[4]
            {
              new Tire(1, 2.5),
              new Tire(1, 2.1),
              new Tire(2, 0.5),
              new Tire(2, 2.3),
            };
            Engine engine = new Engine(560, 6300);
            Car car = new Car(make, model, year, fuelConsumption, fuelQuantity, engine, tires);
        }
    }
}