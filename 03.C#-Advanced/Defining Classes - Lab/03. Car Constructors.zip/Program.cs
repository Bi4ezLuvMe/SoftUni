﻿using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CarManufacturer
{
    public class Car
    {
        public string Make;
        public string Model;
        public int Year;
        public double FuelConsumption;
        public double FuelQuantity;
        public Car()
        {
            Make = "VW";
            Model = "Golf";
            Year = 2025;
            FuelQuantity = 200;
            FuelConsumption = 10;
        }
        public Car(string make,string model,int year):this()
        {
            this.Make = make;
            this.Model = model;
            this.Year = year;
        }
        public Car(string make, string model, int year, double fuelConsumption, double fuelQuantity) : this(make, model, year)
        {
            FuelConsumption = fuelConsumption;
            FuelQuantity = fuelQuantity;
        }
    }
    
    public class StartUp
    {
        static void Main(string[] args)
        {
            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelConsumption = double.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            Car firstCar = new Car();
            Car secondCar = new Car(make,model,year);
            Car thirdCar = new Car(make,model,year,fuelConsumption,fuelQuantity);
        }
    }
}