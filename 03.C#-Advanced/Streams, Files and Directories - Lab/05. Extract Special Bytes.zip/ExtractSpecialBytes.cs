﻿namespace ExtractSpecialBytes
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class ExtractSpecialBytes
    {
        static void Main()
        {
            string binaryFilePath = @"..\..\..\Files\example.png";
            string bytesFilePath = @"..\..\..\Files\bytes.txt";
            string outputPath = @"..\..\..\Files\output.bin";

            ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
        }

        public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
        {
            byte[] buffer = File.ReadAllBytes(binaryFilePath);
            using (StreamReader reader = new(bytesFilePath))
            {
                    using (StreamWriter writer = new(outputPath))
                    {
                    List<string> numbers = new();
                    while (!reader.EndOfStream)
                    {
                        numbers.Add(reader.ReadLine());
                    }
                    foreach (var item in buffer)
                    {
                        foreach (var item1 in numbers)
                        {
                            if (item.ToString()==(item1))
                            {
                                Console.WriteLine(item.ToString());
                            }
                        }
                    }
                    }
                }
            }
        }
    }

