﻿namespace SplitMergeBinaryFile
{
    using System.IO;

    public class SplitMergeBinaryFile
    {
        static void Main()
        {
            string sourceFilePath = @"..\..\..\Files\example.png";
            string joinedFilePath = @"..\..\..\Files\example-joined.png";
            string partOnePath = @"..\..\..\Files\part-1.bin";
            string partTwoPath = @"..\..\..\Files\part-2.bin";

            SplitBinaryFile(sourceFilePath, partOnePath, partTwoPath);
            MergeBinaryFiles(partOnePath, partTwoPath, joinedFilePath);
        }

        public static void SplitBinaryFile(string sourceFilePath, string partOneFilePath, string partTwoFilePath)
        {
            byte[] buffer = File.ReadAllBytes(sourceFilePath);
            if (buffer.Length % 2 == 0)
            {
                using (StreamWriter writer = new(partOneFilePath))
                {
                    for (int i = 0; i < buffer.Length / 2; i++)
                    {
                        writer.Write(buffer[i]);
                    }
                }
                using (StreamWriter writer = new(partTwoFilePath))
                {
                    for (int i = 0; i < buffer.Length / 2; i++)
                    {
                        writer.Write(buffer[i]);
                    }
                }
            }
            else
            {
                using (StreamWriter writer = new(partOneFilePath))
                {
                    for (int i = 0; i < buffer.Length / 2 ; i++)
                    {
                        writer.WriteLine(buffer[i]);
                    }
                }
                using (StreamWriter writer = new(partTwoFilePath))
                {
                    for (int i = 0; i < buffer.Length / 2 + 1; i++)
                    {
                        writer.WriteLine(buffer[i]);
                    }
                }
            }
        }

        public static void MergeBinaryFiles(string partOneFilePath, string partTwoFilePath, string joinedFilePath)
        {
            byte[]buffer = new byte[partOneFilePath.Length+partTwoFilePath.Length];
            using (StreamReader reader = new(partOneFilePath))
            {
                using (StreamReader reader2 = new(partTwoFilePath))
                {
                    using (StreamWriter writer = new(joinedFilePath))
                    {
                        while(!reader.EndOfStream)
                        {
                            writer.WriteLine(reader.ReadLine());
                        }
                        while (!reader2.EndOfStream)
                        {
                            writer.WriteLine(reader2.ReadLine());
                        }
                    }
                }
            }

        }
    }
}