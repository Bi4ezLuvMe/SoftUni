﻿namespace WordCount
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    public class WordCount
    {
        static void Main()
        {
            string wordPath = @"..\..\..\Files\words.txt";
            string textPath = @"..\..\..\Files\text.txt";
            string outputPath = @"..\..\..\Files\output.txt";

            CalculateWordCounts(wordPath, textPath, outputPath);
        }

        public static void CalculateWordCounts(string wordsFilePath, string textFilePath, string outputFilePath)
        {
            using (StreamReader readerTEXT = new(wordsFilePath))
            {
                using(StreamReader reader = new(textFilePath)) 
                {
                    using(StreamWriter writer = new(outputFilePath)) 
                    {
                        string[] words = readerTEXT.ReadToEnd().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                        Dictionary<string, int> counter = new();
                        for (int i = 0; i < words.Length; i++)
                        {
                            counter.Add(words[i],0);
                        }
                        string[] text = reader.ReadToEnd().ToLower().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < words.Length; i++)
                        {
                            for (int j = 0; j < text.Length; j++)
                            {
                                if (words[i] == text[j])
                                {
                                    counter[words[i]]++;
                                }
                            }
                        }
                        counter = counter.OrderByDescending(x => x.Value).ToDictionary(x=>x.Key,x=>x.Value);
                        foreach (var item in counter)
                        {
                           writer.WriteLine($"{item.Key} - {item.Value}");
                        }
                    }
                }
            }

        }
    }
}
