﻿namespace FolderSize
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Linq;

    public class FolderSize
    {
        static void Main(string[] args)
        {
            string folderPath = @"..\..\..\Files\TestFolder";
            string outputPath = @"..\..\..\Files\output.txt";

            GetFolderSize(folderPath, outputPath);
        }

        public static void GetFolderSize(string folderPath, string outputFilePath)
        {
            decimal kb = 0;
            FileInfo finfo = new FileInfo(folderPath);
            kb += finfo.Length;
            using(StreamWriter writer = new StreamWriter(outputFilePath))
            {
                writer.Write($"{kb} KB");
            }
        }
    }
}
