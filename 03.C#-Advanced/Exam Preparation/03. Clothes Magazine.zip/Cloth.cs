﻿using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ClothesMagazine
{
    public class Cloth
    {
        public string Color { get; set; }
        public int Size { get; set; }
        public string Type { get; set; }
        public Cloth(string color, int size, string type) 
        {
            Color = color;
            Size =size; Type = type;
        }
        public override string ToString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append($"Product: {Type} with size {Size}, color {Color}");
            return stringBuilder.ToString().TrimEnd();
        }
    }
}
