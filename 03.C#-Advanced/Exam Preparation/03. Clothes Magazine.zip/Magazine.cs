﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClothesMagazine
{
    public class Magazine
    {
        public List<Cloth> clothes;
        public string Type { get; set; }
        public int Capacity { get; set; }
        public Magazine(string type, int capacity)
        {
            Type = type;
            Capacity = capacity;
            clothes = new List<Cloth>();
        }
        public void AddCloth(Cloth cloth)
        {
            if(clothes.Count<Capacity)
            {
                clothes.Add(cloth);
            }
        }
        public bool RemoveCloth(string color)
        {
            foreach(var item in clothes)
            {
                if(item.Color==color) 
                {
                    clothes.Remove(item);
                    return true; 
                }
            }
            return false;
        }
        public Cloth GetSmallestCloth()
        {
            int min = int.MaxValue;
            Cloth best = null;
            foreach(var item in clothes)
            {
                if(item.Size<=min)
                {
                    best = item;
                    min = item.Size;
                }
            }
            return best;
        }
        public Cloth GetCloth(string color)
        {
            return clothes.FirstOrDefault(x=> x.Color==color);
        }
        public int GetClothCount()
        {
            return clothes.Count;
        }
        public string Report()
        {
            StringBuilder sb = new StringBuilder();
                sb.AppendLine($"{Type} magazine contains:");
            clothes=clothes.OrderBy(x => x.Size).ToList();
            foreach (var item in clothes)
            {
                sb.AppendLine(item.ToString());
            }
               return sb.ToString().TrimEnd();
        }
    }
}
